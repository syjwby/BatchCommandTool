# PowerShell Command Reference

## File Operations

### Get-ChildItem - List Files and Directories
```powershell
Get-ChildItem [[-Path] <String[]>] [[-Filter] <String>] [-Recurse] [-Name] [-File] [-Directory] [-Hidden] [-ReadOnly] [-System] [-Force] [-Depth <UInt32>]
```
**Aliases:** `dir`, `ls`, `gci`
**Examples:**
```powershell
Get-ChildItem                       # List current directory
Get-ChildItem -Path C:\ -Recurse    # List all files recursively
Get-ChildItem -Filter *.txt         # Filter by extension
Get-ChildItem -Hidden               # Include hidden files
Get-ChildItem -File | Sort-Object Length -Descending  # Sort by size
```

### Copy-Item - Copy Files and Directories
```powershell
Copy-Item [-Path] <String[]> [[-Destination] <String>] [-Container] [-Recurse] [-Force] [-Filter <String>] [-Include <String[]>] [-Exclude <String[]>] [-PassThru] [-Credential <PSCredential>]
```
**Aliases:** `copy`, `cp`, `cpi`
**Examples:**
```powershell
Copy-Item file.txt backup.txt      # Copy single file
Copy-Item -Path folder1 -Destination folder2 -Recurse  # Copy directory
Copy-Item *.txt backup\            # Copy with wildcard
```

### Move-Item - Move Files and Directories
```powershell
Move-Item [-Path] <String[]> [[-Destination] <String>] [-Force] [-Filter <String>] [-Include <String[]>] [-Exclude <String[]>] [-PassThru] [-Credential <PSCredential>]
```
**Aliases:** `move`, `mv`, `mi`
**Examples:**
```powershell
Move-Item file.txt newfolder\      # Move file
Move-Item -Path oldname.txt -Destination newname.txt  # Rename
```

### Remove-Item - Delete Files and Directories
```powershell
Remove-Item [-Path] <String[]> [-Recurse] [-Force] [-Filter <String>] [-Include <String[]>] [-Exclude <String[]>] [-Confirm] [-WhatIf] [-Credential <PSCredential>]
```
**Aliases:** `remove`, `rm`, `rmi`, `del`, `erase`, `rd`, `ri`
**Examples:**
```powershell
Remove-Item file.txt               # Delete file
Remove-Item -Path folder -Recurse -Force  # Delete directory
Remove-Item -Path *.tmp -Confirm   # Confirm before delete
```

### Rename-Item - Rename Files and Directories
```powershell
Rename-Item [-Path] <String> [-NewName] <String> [-Force] [-PassThru] [-Credential <PSCredential>]
```
**Aliases:** `rni`, `ren`
**Examples:**
```powershell
Rename-Item file.txt newfile.txt   # Rename file
Rename-Item -Path *.txt -NewName { $_.Name -replace '\.txt$','.bak' }  # Batch rename
```

### New-Item - Create New Files and Directories
```powershell
New-Item [-Path] <String[]> [-ItemType <String>] [-Force] [-Value <Object>] [-Credential <PSCredential>]
```
**Aliases:** `ni`
**Examples:**
```powershell
New-Item -Path newfolder -ItemType Directory    # Create directory
New-Item -Path newfile.txt -ItemType File        # Create file
```

### Set-Content - Write Content to File
```powershell
Set-Content [-Path] <String[]> [-Value] <Object[]> [-PassThru] [-Force] [-Encoding <Encoding>] [-Credential <PSCredential>]
```
**Aliases:** `sc`
**Examples:**
```powershell
Set-Content -Path file.txt -Value "Hello World"  # Write text
Get-Process | Set-Content processes.txt           # Write command output
```

### Get-Content - Read File Content
```powershell
Get-Content [-Path] <String[]> [-TotalCount <Int64>] [-Tail <Int32>] [-Filter <String>] [-Encoding <Encoding>] [-ReadCount <Int64>] [-Delimiter <String>] [-Raw] [-Wait]
```
**Aliases:** `cat`, `gc`, `type`
**Examples:**
```powershell
Get-Content file.txt                 # Read file
Get-Content file.txt -Tail 10        # Read last 10 lines
Get-Content file.txt -TotalCount 5  # Read first 5 lines
```

## Directory Operations

### Set-Location - Change Directory
```powershell
Set-Location [[-Path] <String>] [-PassThru]
```
**Aliases:** `cd`, `chdir`, `sl`
**Examples:**
```powershell
Set-Location C:\                     # Go to root
Set-Location ..                      # Go to parent
Set-Location $env:USERPROFILE       # Go to home
```

### Push-Location / Pop-Location - Directory Stack
```powershell
Push-Location [[-Path] <String>] [-PassThru]
Pop-Location [-PassThru]
```
**Aliases:** `pushd`, `popd`
**Examples:**
```powershell
Push-Location C:\Windows            # Save and go
Pop-Location                        # Return to previous
```

### Test-Path - Check Path Existence
```powershell
Test-Path [-Path] <String[]> [-PathType <PathType>] [-IsValid] [-Filter <String>] [-Include <String[]>] [-Exclude <String[]>]
```
**Examples:**
```powershell
Test-Path file.txt                  # Check if file exists
Test-Path C:\folder -PathType Container  # Check if directory exists
```

## System Commands

### Get-ItemProperty - Get File/Directory Properties
```powershell
Get-ItemProperty [-Path] <String[]> [[-Name] <String[]>] [-Filter <String>] [-Include <String[]>] [-Exclude <String[]>]
```
**Aliases:** `gp`
**Examples:**
```powershell
Get-ItemProperty file.txt | Format-List  # List all properties
Get-ItemProperty file.txt LastWriteTime  # Get specific property
```

### Set-ItemProperty - Set File/Directory Properties
```powershell
Set-ItemProperty [-Path] <String[]> [-Name] <String[]> [-Value] <Object> [-PassThru] [-Force]
```
**Examples:**
```powershell
Set-ItemProperty -Path file.txt -Name IsReadOnly -Value $true  # Set read-only
Set-ItemProperty -Path file.txt -Name LastWriteTime -Value (Get-Date)  # Set timestamp
```

### Get-ACL / Set-ACL - Manage Permissions
```powershell
Get-Acl [[-Path] <String[]>] [-Audit] [-Filter <String>] [-Include <String[]>] [-Exclude <String[]>]
Set-Acl [-Path] <String[]> [-AclObject] <Object> [-Filter <String>] [-Include <String[]>] [-Exclude <String[]>] [-PassThru] [-WhatIf] [-Confirm]
```
**Examples:**
```powershell
Get-Acl file.txt | Format-List      # Get permissions
(Get-Acl file.txt).Access           # List access rules
```

## Search and Filter

### Where-Object - Filter Objects
```powershell
Where-Object [-FilterScript] <ScriptBlock>
```
**Aliases:** `where`, `?`
**Examples:**
```powershell
Get-ChildItem | Where-Object { $_.Length -gt 100MB }  # Files > 100MB
Get-Process | Where-Object { $_.CPU -gt 10 }           # High CPU processes
Get-ChildItem | Where-Object { $_.Name -match '^\d+' } # Name starts with number
```

### Select-Object - Select Properties
```powershell
Select-Object [[-Property] <Object[]>] [-First <Int64>] [-Last <Int64>] [-Unique] [-Skip <Int64>] [-ExpandProperty <String>]
```
**Aliases:** `select`
**Examples:**
```powershell
Get-ChildItem | Select-Object Name, Length  # Select properties
Get-Process | Select-Object -First 5         # First 5 items
```

### Sort-Object - Sort Objects
```powershell
Sort-Object [[-Property] <Object[]>] [-Descending] [-Unique] [-CaseSensitive]
```
**Aliases:** `sort`
**Examples:**
```powershell
Get-ChildItem | Sort-Object Length -Descending  # Sort by size
Get-ChildItem | Sort-Object Name                 # Sort by name
Get-ChildItem | Sort-Object LastWriteTime        # Sort by date
```

### ForEach-Object - Process Each Object
```powershell
ForEach-Object [-Process] <ScriptBlock[]> [-Begin <ScriptBlock>] [-End <ScriptBlock>]
```
**Aliases:** `foreach`, `%`
**Examples:**
```powershell
1..10 | ForEach-Object { $_ * 2 }        # Double numbers
Get-ChildItem | ForEach-Object { $_.Name.ToUpper() }  # Uppercase names
```

## Variables and Scripts

### Variables
```powershell
$variable = "value"                      # Create variable
${variable name} = "value"              # Variable with spaces
$null, $true, $false                    # Special values
$env:VARIABLE = "value"                  # Environment variable
```
**Examples:**
```powershell
$name = "World"
$number = 42
$files = Get-ChildItem
$env:PATH -split ';'                     # Split string
```

### If Statement
```powershell
if (<condition>) { <statement_list> }
elseif (<condition>) { <statement_list> }
else { <statement_list> }
```
**Examples:**
```powershell
if ($age -ge 18) { "Adult" }
elseif ($age -ge 13) { "Teen" }
else { "Child" }

if (Test-Path file.txt) { "Exists" } else { "Not found" }
```

### Switch Statement
```powershell
switch (<test_value>) {
    <value1> { <statement_list> }
    <value2> { <statement_list> }
    default { <statement_list> }
}
```
**Examples:**
```powershell
switch ($status) {
    "active" { "Status is active" }
    "pending" { "Status is pending" }
    default { "Unknown status" }
}
```

### For Loop
```powershell
for (<init>; <condition>; <repeat>) { <statement_list> }
```
**Examples:**
```powershell
for ($i = 0; $i -lt 10; $i++) { Write-Host $i }
for ($i = 1; $i -le 5; $i++) { "Item $i" }
```

### ForEach Loop
```powershell
foreach ($item in $collection) { <statement_list> }
```
**Examples:**
```powershell
$colors = "Red", "Green", "Blue"
foreach ($color in $colors) { $color }

foreach ($file in Get-ChildItem) { $file.Name }
```

### While Loop
```powershell
while (<condition>) { <statement_list> }
do { <statement_list> } while (<condition>)
```
**Examples:**
```powershell
$i = 0
while ($i -lt 5) {
    $i++
    Write-Host $i
}
```

## Comparison Operators

| Operator | Description | Example |
|----------|-------------|---------|
| `-eq` | Equal | `$a -eq $b` |
| `-ne` | Not equal | `$a -ne $b` |
| `-gt` | Greater than | `$a -gt $b` |
| `-ge` | Greater or equal | `$a -ge $b` |
| `-lt` | Less than | `$a -lt $b` |
| `-le` | Less or equal | `$a -le $b` |
| `-like` | Wildcard match | `$a -like "*.txt"` |
| `-notlike` | Not wildcard | `$a -notlike "*.txt"` |
| `-match` | Regex match | `$a -match "^\d+"` |
| `-contains` | Contains | `$a -contains $b` |
| `-in` | In collection | `$a -in $collection` |

## String Operations

```powershell
"Hello" + " " + "World"               # Concatenate
"{0} {1}" -f "Hello", "World"        # Format string
$name = "John"
"Hello $name"                          # String interpolation
'Hello $name'                         # Literal string
$text.Length                           # String length
$text.Substring(0, 5)                  # Extract substring
$text.Replace("old", "new")            # Replace
$text.ToUpper() / ToLower()           # Change case
$text.Trim() / TrimStart() / TrimEnd()  # Remove whitespace
$text.Split(",")                       # Split string
$text -split ","                       # Split with operator
$text -join ","                        # Join array
```

## Pipeline Operations

```powershell
# Pipe output to file
Get-Process > processes.txt
Get-Process | Out-File processes.txt

# Pipe and filter
Get-ChildItem | Where-Object { $_.Size -gt 1MB } | Sort-Object Size

# Multiple operations
Get-ChildItem -Filter *.txt |
    Where-Object { $_.LastWriteTime -gt (Get-Date).AddDays(-7) } |
    Sort-Object LastWriteTime -Descending |
    Select-Object Name, Length, LastWriteTime
```

## Common Parameters

| Parameter | Description |
|-----------|-------------|
| `-Verbose` | Detailed output |
| `-Debug` | Debug information |
| `-ErrorAction` | How to handle errors (Continue, Stop, SilentlyContinue, Inquire) |
| `-WhatIf` | Preview without executing |
| `-Confirm` | Prompt for confirmation |
| `-Force` | Force operation |
| `-Recurse` | Include subdirectories |
| `-Include` | Include specific items |
| `-Exclude` | Exclude specific items |

## Tips

- Use `Get-Help <cmdlet-name>` for detailed help
- Use `Get-Help <cmdlet-name> -Examples` for examples
- Use `Get-Command` to discover available commands
- Use `Update-Help` to update help files
- Use `$ErrorActionPreference` to control error handling
- Use `-WhatIf` to preview dangerous operations
- Use `$_` or `$PSItem` to reference current object in pipeline
- Use `.ps1` extension for PowerShell scripts
- Use `.\script.ps1` to run scripts in current directory
