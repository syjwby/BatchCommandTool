# PowerShell 命令参考

## 文件操作

### Get-ChildItem - 列出文件和目录
```powershell
Get-ChildItem [[-Path] <String[]>] [[-Filter] <String>] [-Recurse] [-Name] [-File] [-Directory] [-Hidden] [-ReadOnly] [-System] [-Force] [-Depth <UInt32>]
```
**别名:** `dir`, `ls`, `gci`
**示例:**
```powershell
Get-ChildItem                       # 列出当前目录
Get-ChildItem -Path C:\ -Recurse    # 递归列出所有文件
Get-ChildItem -Filter *.txt         # 按扩展名筛选
Get-ChildItem -Hidden               # 包含隐藏文件
Get-ChildItem -File | Sort-Object Length -Descending  # 按大小排序
```

### Copy-Item - 复制文件和目录
```powershell
Copy-Item [-Path] <String[]> [[-Destination] <String>] [-Container] [-Recurse] [-Force] [-Filter <String>] [-Include <String[]>] [-Exclude <String[]>] [-PassThru] [-Credential <PSCredential>]
```
**别名:** `copy`, `cp`, `cpi`
**示例:**
```powershell
Copy-Item file.txt backup.txt      # 复制单个文件
Copy-Item -Path folder1 -Destination folder2 -Recurse  # 复制目录
Copy-Item *.txt backup\            # 使用通配符复制
```

### Move-Item - 移动/重命名文件和目录
```powershell
Move-Item [-Path] <String[]> [[-Destination] <String>] [-Force] [-Filter <String>] [-Include <String[]>] [-Exclude <String[]>] [-PassThru] [-Credential <PSCredential>]
```
**别名:** `move`, `mv`, `mi`
**示例:**
```powershell
Move-Item file.txt newfolder\      # 移动文件
Move-Item -Path oldname.txt -Destination newname.txt  # 重命名
```

### Remove-Item - 删除文件和目录
```powershell
Remove-Item [-Path] <String[]> [-Recurse] [-Force] [-Filter <String>] [-Include <String[]>] [-Exclude <String[]>] [-Confirm] [-WhatIf] [-Credential <PSCredential>]
```
**别名:** `remove`, `rm`, `rmi`, `del`, `erase`, `rd`, `ri`
**示例:**
```powershell
Remove-Item file.txt               # 删除文件
Remove-Item -Path folder -Recurse -Force  # 删除目录
Remove-Item -Path *.tmp -Confirm   # 删除前确认
```

### Rename-Item - 重命名文件和目录
```powershell
Rename-Item [-Path] <String> [-NewName] <String> [-Force] [-PassThru] [-Credential <PSCredential>]
```
**别名:** `rni`, `ren`
**示例:**
```powershell
Rename-Item file.txt newfile.txt   # 重命名文件
Rename-Item -Path *.txt -NewName { $_.Name -replace '\.txt$','.bak' }  # 批量重命名
```

### New-Item - 创建新文件和目录
```powershell
New-Item [-Path] <String[]> [-ItemType <String>] [-Force] [-Value <Object>] [-Credential <PSCredential>]
```
**别名:** `ni`
**示例:**
```powershell
New-Item -Path newfolder -ItemType Directory    # 创建目录
New-Item -Path newfile.txt -ItemType File        # 创建文件
```

### Set-Content - 写入文件内容
```powershell
Set-Content [-Path] <String[]> [-Value] <Object[]> [-PassThru] [-Force] [-Encoding <Encoding>] [-Credential <PSCredential>]
```
**别名:** `sc`
**示例:**
```powershell
Set-Content -Path file.txt -Value "Hello World"  # 写入文本
Get-Process | Set-Content processes.txt           # 写入命令输出
```

### Get-Content - 读取文件内容
```powershell
Get-Content [-Path] <String[]> [-TotalCount <Int64>] [-Tail <Int32>] [-Filter <String>] [-Encoding <Encoding>] [-ReadCount <Int64>] [-Delimiter <String>] [-Raw] [-Wait]
```
**别名:** `cat`, `gc`, `type`
**示例:**
```powershell
Get-Content file.txt                 # 读取文件
Get-Content file.txt -Tail 10        # 读取最后10行
Get-Content file.txt -TotalCount 5  # 读取前5行
```

## 目录操作

### Set-Location - 切换目录
```powershell
Set-Location [[-Path] <String>] [-PassThru]
```
**别名:** `cd`, `chdir`, `sl`
**示例:**
```powershell
Set-Location C:\                     # 切换到根目录
Set-Location ..                      # 切换到上级目录
Set-Location $env:USERPROFILE       # 切换到用户主目录
```

### Push-Location / Pop-Location - 目录栈
```powershell
Push-Location [[-Path] <String>] [-PassThru]
Pop-Location [-PassThru]
```
**别名:** `pushd`, `popd`
**示例:**
```powershell
Push-Location C:\Windows            # 保存并切换
Pop-Location                        # 返回上一个目录
```

### Test-Path - 检查路径是否存在
```powershell
Test-Path [-Path] <String[]> [-PathType <PathType>] [-IsValid] [-Filter <String>] [-Include <String[]>] [-Exclude <String[]>]
```
**示例:**
```powershell
Test-Path file.txt                  # 检查文件是否存在
Test-Path C:\folder -PathType Container  # 检查目录是否存在
```

## 系统命令

### Get-ItemProperty - 获取文件/目录属性
```powershell
Get-ItemProperty [-Path] <String[]> [[-Name] <String[]>] [-Filter <String>] [-Include <String[]>] [-Exclude <String[]>]
```
**别名:** `gp`
**示例:**
```powershell
Get-ItemProperty file.txt | Format-List  # 列出所有属性
Get-ItemProperty file.txt LastWriteTime  # 获取特定属性
```

### Set-ItemProperty - 设置文件/目录属性
```powershell
Set-ItemProperty [-Path] <String[]> [-Name] <String[]> [-Value] <Object> [-PassThru] [-Force]
```
**示例:**
```powershell
Set-ItemProperty -Path file.txt -Name IsReadOnly -Value $true  # 设置只读
Set-ItemProperty -Path file.txt -Name LastWriteTime -Value (Get-Date)  # 设置时间戳
```

### Get-ACL / Set-ACL - 权限管理
```powershell
Get-Acl [[-Path] <String[]>] [-Audit] [-Filter <String>] [-Include <String[]>] [-Exclude <String[]>]
Set-Acl [-Path] <String[]> [-AclObject] <Object> [-Filter <String>] [-Include <String[]>] [-Exclude <String[]>] [-PassThru] [-WhatIf] [-Confirm]
```
**示例:**
```powershell
Get-Acl file.txt | Format-List      # 获取权限
(Get-Acl file.txt).Access           # 列出访问规则
```

## 搜索和筛选

### Where-Object - 筛选对象
```powershell
Where-Object [-FilterScript] <ScriptBlock>
```
**别名:** `where`, `?`
**示例:**
```powershell
Get-ChildItem | Where-Object { $_.Length -gt 100MB }  # 文件大于100MB
Get-Process | Where-Object { $_.CPU -gt 10 }           # 高CPU进程
Get-ChildItem | Where-Object { $_.Name -match '^\d+' } # 名称以数字开头
```

### Select-Object - 选择属性
```powershell
Select-Object [[-Property] <Object[]>] [-First <Int64>] [-Last <Int64>] [-Unique] [-Skip <Int64>] [-ExpandProperty <String>]
```
**别名:** `select`
**示例:**
```powershell
Get-ChildItem | Select-Object Name, Length  # 选择属性
Get-Process | Select-Object -First 5         # 前5项
```

### Sort-Object - 排序对象
```powershell
Sort-Object [[-Property] <Object[]>] [-Descending] [-Unique] [-CaseSensitive]
```
**别名:** `sort`
**示例:**
```powershell
Get-ChildItem | Sort-Object Length -Descending  # 按大小排序
Get-ChildItem | Sort-Object Name                 # 按名称排序
Get-ChildItem | Sort-Object LastWriteTime        # 按时间排序
```

### ForEach-Object - 处理每个对象
```powershell
ForEach-Object [-Process] <ScriptBlock[]> [-Begin <ScriptBlock>] [-End <ScriptBlock>]
```
**别名:** `foreach`, `%`
**示例:**
```powershell
1..10 | ForEach-Object { $_ * 2 }        # 数字翻倍
Get-ChildItem | ForEach-Object { $_.Name.ToUpper() }  # 名称转大写
```

## 变量和脚本

### 变量
```powershell
$variable = "value"                      # 创建变量
${variable name} = "value"              # 含空格的变量名
$null, $true, $false                    # 特殊值
$env:VARIABLE = "value"                  # 环境变量
```
**示例:**
```powershell
$name = "World"
$number = 42
$files = Get-ChildItem
$env:PATH -split ';'                     # 分割字符串
```

### If 语句
```powershell
if (<条件>) { <语句列表> }
elseif (<条件>) { <语句列表> }
else { <语句列表> }
```
**示例:**
```powershell
if ($age -ge 18) { "成年人" }
elseif ($age -ge 13) { "青少年" }
else { "儿童" }

if (Test-Path file.txt) { "存在" } else { "不存在" }
```

### Switch 语句
```powershell
switch (<测试值>) {
    <值1> { <语句列表> }
    <值2> { <语句列表> }
    default { <语句列表> }
}
```
**示例:**
```powershell
switch ($status) {
    "active" { "状态为活动" }
    "pending" { "状态为待处理" }
    default { "未知状态" }
}
```

### For 循环
```powershell
for (<初始化>; <条件>; <重复>) { <语句列表> }
```
**示例:**
```powershell
for ($i = 0; $i -lt 10; $i++) { Write-Host $i }
for ($i = 1; $i -le 5; $i++) { "项目 $i" }
```

### ForEach 循环
```powershell
foreach ($item in $collection) { <语句列表> }
```
**示例:**
```powershell
$colors = "红色", "绿色", "蓝色"
foreach ($color in $colors) { $color }

foreach ($file in Get-ChildItem) { $file.Name }
```

### While 循环
```powershell
while (<条件>) { <语句列表> }
do { <语句列表> } while (<条件>)
```
**示例:**
```powershell
$i = 0
while ($i -lt 5) {
    $i++
    Write-Host $i
}
```

## 比较运算符

| 运算符 | 描述 | 示例 |
|--------|------|------|
| `-eq` | 等于 | `$a -eq $b` |
| `-ne` | 不等于 | `$a -ne $b` |
| `-gt` | 大于 | `$a -gt $b` |
| `-ge` | 大于或等于 | `$a -ge $b` |
| `-lt` | 小于 | `$a -lt $b` |
| `-le` | 小于或等于 | `$a -le $b` |
| `-like` | 通配符匹配 | `$a -like "*.txt"` |
| `-notlike` | 不匹配通配符 | `$a -notlike "*.txt"` |
| `-match` | 正则表达式匹配 | `$a -match "^\d+"` |
| `-contains` | 包含 | `$a -contains $b` |
| `-in` | 在集合中 | `$a -in $collection` |

## 字符串操作

```powershell
"Hello" + " " + "World"               # 拼接
"{0} {1}" -f "Hello", "World"        # 格式化字符串
$name = "John"
"Hello $name"                        # 字符串插值
'Hello $name'                         # 字面字符串
$text.Length                          # 字符串长度
$text.Substring(0, 5)                 # 提取子字符串
$text.Replace("old", "new")          # 替换
$text.ToUpper() / ToLower()          # 更改大小写
$text.Trim() / TrimStart() / TrimEnd()  # 去除空白
$text.Split(",")                     # 分割字符串
$text -split ","                      # 使用运算符分割
$text -join ","                       # 连接数组
```

## 管道操作

```powershell
# 管道输出到文件
Get-Process > processes.txt
Get-Process | Out-File processes.txt

# 管道筛选
Get-ChildItem | Where-Object { $_.Size -gt 1MB } | Sort-Object Size

# 多个操作
Get-ChildItem -Filter *.txt |
    Where-Object { $_.LastWriteTime -gt (Get-Date).AddDays(-7) } |
    Sort-Object LastWriteTime -Descending |
    Select-Object Name, Length, LastWriteTime
```

## 常用参数

| 参数 | 描述 |
|------|------|
| `-Verbose` | 详细输出 |
| `-Debug` | 调试信息 |
| `-ErrorAction` | 错误处理方式 (Continue, Stop, SilentlyContinue, Inquire) |
| `-WhatIf` | 预览不执行 |
| `-Confirm` | 执行前确认 |
| `-Force` | 强制操作 |
| `-Recurse` | 包含子目录 |
| `-Include` | 包含特定项 |
| `-Exclude` | 排除特定项 |

## 技巧

- 使用 `Get-Help <cmdlet名称>` 获取详细帮助
- 使用 `Get-Help <cmdlet名称> -Examples` 查看示例
- 使用 `Get-Command` 发现可用命令
- 使用 `Update-Help` 更新帮助文件
- 使用 `$ErrorActionPreference` 控制错误处理
- 使用 `-WhatIf` 预览危险操作
- 使用 `$_` 或 `$PSItem` 引用管道中的当前对象
- 使用 `.ps1` 扩展名保存PowerShell脚本
- 使用 `.\script.ps1` 运行当前目录的脚本
