# CMD 命令参考

## 文件操作

### DIR - 显示目录内容
```
DIR [驱动器:][路径][文件名] [/A:属性] [/B] [/C] [/D] [/L] [/N] [/O:顺序] [/P] [/Q] [/R] [/S] [/T:时间] [/W] [/X] [/4]
```
**示例:**
```
DIR                     - 列出当前目录
DIR /A:H                - 列出隐藏文件
DIR /S                  - 列出子目录中的文件
DIR /O:-S               - 按大小排序（最大优先）
DIR /TC                 - 显示创建时间
```

### COPY - 复制文件
```
COPY 源 目标 [/D] [/V] [/N] [/Y] [/Z] [/L] [/A] [/B]
```
**示例:**
```
COPY file.txt backup.txt           - 复制单个文件
COPY *.txt backup\                  - 复制所有txt文件
COPY /V file1.txt file2.txt        - 复制后验证
```

### MOVE - 移动/重命名文件
```
MOVE [/Y | /-Y] [驱动器:][路径]文件名1[,...] 目标
```
**示例:**
```
MOVE oldname.txt newname.txt       - 重命名文件
MOVE file.txt newfolder\           - 移动文件
```

### DEL/ERASE - 删除文件
```
DEL [/P] [/F] [/S] [/Q] [/A:属性] 文件名
ERASE [/P] [/F] [/S] [/Q] [/A:属性] 文件名
```
**示例:**
```
DEL file.txt                       - 删除单个文件
DEL *.tmp /Q                      - 静默删除（无需确认）
DEL /S *.bak                      - 删除包括子目录
```

### REN/RENAME - 重命名文件
```
REN [驱动器:][路径]文件名1 文件名2
RENAME [驱动器:][路径]文件名1 文件名2
```
**示例:**
```
REN *.txt *.bak                   - 更改扩展名
REN oldname newname                - 重命名文件
```

### XCOPY - 扩展复制
```
XCOPY 源 [目标] [/A] [/C] [/D:日期] [/E] [/F] [/H] [/I] [/K] [/L] [/M] [/N] [/O] [/P] [/Q] [/R] [/S] [/T] [/U] [/V] [/W] [/X] [/Y] [/Z]
```
**示例:**
```
XCOPY folder1 folder2 /E /I        - 复制整个目录
XCOPY /S /I source\*.* dest\      - 带结构复制
```

### ROBOCOPY - 可靠文件复制
```
ROBOCOPY 源 目标 [文件] [选项]
```
**示例:**
```
ROBOCOPY C:\src D:\dst /MIR       - 镜像目录
ROBOCOPY /E /XO source dest       - 复制排除旧文件
```

## 目录操作

### CD/CHDIR - 切换目录
```
CD [/D] [驱动器:][路径]
CHDIR [/D] [驱动器:][路径]
```
**示例:**
```
CD ..                             - 返回上级目录
CD \folder\subfolder              - 切换到指定路径
```

### MD/MKDIR - 创建目录
```
MD [驱动器:]路径
MKDIR [驱动器:]路径
```
**示例:**
```
MD newfolder                      - 创建单个目录
MD folder1 folder2 folder3        - 创建多个目录
```

### RD/RMDIR - 删除目录
```
RD [/S] [/Q] [驱动器:]路径
RMDIR [/S] [/Q] [驱动器:]路径
```
**示例:**
```
RD emptyfolder                    - 删除空目录
RD /S folder                      - 删除包括子目录
RD /S /Q folder                  - 静默删除
```

### PUSHD/POPD - 目录栈
```
PUSHD [路径]
POPD
```
**示例:**
```
PUSHD C:\folder                   - 保存并切换目录
POPD                              - 返回上一个目录
```

## 系统命令

### ATTRIB - 显示/更改文件属性
```
ATTRIB [+属性|-属性] [文件名] [/S] [/D]
```
**属性:** H (隐藏), R (只读), S (系统), A (存档)
**示例:**
```
ATTRIB +H file.txt                - 隐藏文件
ATTRIB -R *.txt /S                - 移除所有txt的只读属性
```

### FIND - 搜索文本
```
FIND [/V] [/C] [/N] "字符串" [驱动器:][路径]文件名
```
**示例:**
```
FIND "error" log.txt              - 在文件中查找字符串
FIND /I "case insensitive" file   - 不区分大小写搜索
```

### FINDSTR - 高级搜索
```
FINDSTR [/X] [/I] [/S] "模式" [文件]
```
**示例:**
```
FINDSTR "error\|warning" *.log   - 多个模式
FINDSTR /S /I "text" *.*          - 递归不区分大小写
```

### TYPE - 显示文件内容
```
TYPE [驱动器:][路径]文件名
```
**示例:**
```
TYPE file.txt                     - 显示文件内容
TYPE file1.txt file2.txt         - 显示多个文件
```

### MORE - 分页显示
```
MORE [/E] [/C] [/P] [/S] [文件]
命令 | MORE [/E] [/C] [/P] [/S]
```
**示例:**
```
TYPE longfile.txt | MORE          - 长输出分页
```

### SORT - 排序输入
```
SORT [/R] [/+n] [/M 千克字节] [/L 区域] [/REC 记录字节] [[驱动器1:][路径1]文件名1] [/T [驱动器2:][路径2]] [/O [驱动器3:][路径3]文件名3]
```
**示例:**
```
TYPE file.txt | SORT              - 按字母排序
DIR | SORT /+2 /R                - 按第二列反向排序
```

## 批处理脚本命令

### ECHO - 显示消息
```
ECHO [ON|OFF]
ECHO [消息]
```
**示例:**
```
ECHO Hello World                  - 显示消息
ECHO OFF                          - 禁用命令回显
ECHO.                             - 空行
```

### SET - 显示/设置变量
```
SET [变量=字符串]
SET /A 表达式
SET /P 变量=[提示字符串]
```
**示例:**
```
SET name=value                    - 设置变量
SET /A num=5+3                   - 算术运算
SET /P name=Enter name:           - 用户输入
SET PATH                          - 显示PATH变量
```

### IF - 条件处理
```
IF [NOT] ERRORLEVEL 数字 命令
IF [NOT] 字符串1==字符串2 命令
IF [NOT] EXIST 文件名 命令
IF [/I] 字符串1 比较操作符 字符串2 命令
```
**示例:**
```
IF EXIST file.txt ECHO Found      - 检查文件存在
IF %ERRORLEVEL% NEQ 0 ECHO Error  - 检查错误级别
IF /I "%var%"=="yes" GOTO yes     - 不区分大小写比较
```

### FOR - 循环命令
```
FOR %变量 IN (集合) DO 命令 [命令参数]
FOR /D %变量 IN (集合) DO 命令
FOR /R [[驱动器:]路径] %变量 IN (集合) DO 命令
FOR /L %变量 IN (开始,步长,结束) DO 命令
FOR /F ["选项"] %变量 IN (文件集) DO 命令
```
**示例:**
```
FOR %f IN (*.txt) DO ECHO %f     - 处理文件
FOR /L %i IN (1,1,10) DO ECHO %i - 计数1到10
FOR /R %f IN (*.txt) DO ...      - 递归
```

### GOTO - 跳转到标签
```
GOTO :标签
```
**示例:**
```
GOTO :EOF                         - 文件末尾
GOTO :error                       - 跳转到错误标签
```

### CALL - 调用批处理脚本
```
CALL [驱动器:][路径]文件名 [批处理参数]
```
**示例:**
```
CALL other.bat                    - 调用另一个批处理文件
CALL :subroutine                  - 调用子程序
```

### START - 启动程序
```
START ["标题"] [/D 路径] [/I] [/B] [命令/程序] [参数]
```
**示例:**
```
START notepad.exe file.txt        - 在记事本中打开文件
START "" /WAIT cmd /K            - 新窗口，保持打开
START /MIN cmd /C "command"       - 最小化窗口
```

### TIMEOUT - 延迟执行
```
TIMEOUT /T 秒数 [/NOBREAK]
```
**示例:**
```
TIMEOUT /T 5                      - 等待5秒
TIMEOUT /T 30 /NOBREAK           - 忽略按键
```

## 网络命令

### PING - 测试连接
```
PING [-t] [-a] [-n 次数] [-l 大小] [-f] [-i TTL] 目标
```
**示例:**
```
PING google.com                   - 测试连接
PING -t 192.168.1.1              - 持续ping
PING -n 10 -l 1000 google.com    - 10个包，1000字节
```

### IPCONFIG - 网络配置
```
IPCONFIG [/allcompartments] [/all] [/renew [适配器]] [/release [适配器]] [/flushdns] [/displaydns] [/registerdns] [/showclassid 适配器] [/setclassid 适配器 [类ID]]
```
**示例:**
```
IPCONFIG                          - 显示IP地址
IPCONFIG /ALL                     - 完整配置
IPCONFIG /flushdns               - 清除DNS缓存
```

### NET USE - 映射网络驱动器
```
NET USE [设备名 | *] [\\计算机\共享[\密码]] [/USER:[域\]用户] [/PERSISTENT:YES]
```
**示例:**
```
NET USE Z: \\server\share        - 映射驱动器
NET USE * \\server\share /USER:domain\user  - 带凭据
```

## 变量参考

| 变量 | 说明 |
|------|------|
| `%~1` | 展开%1，移除引号 |
| `%~f1` | 展开%1为完整路径 |
| `%~d1` | 展开%1为驱动器号 |
| `%~p1` | 展开%1为路径 |
| `%~n1` | 展开%1为文件名 |
| `%~x1` | 展开%1为扩展名 |
| `%~dp1` | 展开%1为驱动器+路径 |
| `%~nx1` | 展开%1为文件名+扩展名 |

## 退出代码

| 代码 | 含义 |
|------|------|
| 0 | 成功 |
| 1 | 函数错误 |
| 2 | 文件未找到 |
| 3 | 路径未找到 |
| 4 | 访问被拒绝 |
| 5 | 无效的访问代码 |
| 112 | 磁盘满 |
| 255 | 错误 |

## 技巧

- 使用 `/Y` 开关抑制确认提示
- 使用 `命令 > 文件.txt` 重定向输出到文件
- 使用 `命令 >> 文件.txt` 追加输出到文件
- 使用 `命令1 | 命令2` 管道输出到另一个命令
- 使用 `命令 & 命令2` 同时运行两个命令
- 使用 `命令 && 命令2` 仅当前一个成功时运行后一个
- 使用 `命令 || 命令2` 仅当前一个失败时运行后一个
