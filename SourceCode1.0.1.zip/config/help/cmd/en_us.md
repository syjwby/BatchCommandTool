# CMD Command Reference

## File Operations

### DIR - List Directory Contents
```
DIR [drive:][path][filename] [/A:attribute] [/B] [/C] [/D] [/L] [/N] [/O:order] [/P] [/Q] [/R] [/S] [/T:time] [/W] [/X] [/4]
```
**Examples:**
```
DIR                     - List current directory
DIR /A:H                - List hidden files
DIR /S                  - List files in subdirectories
DIR /O:-S               - Sort by size (largest first)
DIR /TC                 - Show creation time
```

### COPY - Copy Files
```
COPY source destination [/D] [/V] [/N] [/Y] [/Z] [/L] [/A] [/B]
```
**Examples:**
```
COPY file.txt backup.txt           - Copy single file
COPY *.txt backup\                  - Copy all txt files
COPY /V file1.txt file2.txt        - Verify after copy
```

### MOVE - Move/Rename Files
```
MOVE [/Y | /-Y] [drive:][path]filename1[,...] destination
```
**Examples:**
```
MOVE oldname.txt newname.txt       - Rename file
MOVE file.txt newfolder\           - Move file
```

### DEL/ERASE - Delete Files
```
DEL [/P] [/F] [/S] [/Q] [/A:attributes] names
ERASE [/P] [/F] [/S] [/Q] [/A:attributes] names
```
**Examples:**
```
DEL file.txt                       - Delete single file
DEL *.tmp /Q                      - Quiet delete (no confirmation)
DEL /S *.bak                      - Delete with subdirectories
```

### REN/RENAME - Rename Files
```
REN [drive:][path]filename1 filename2
RENAME [drive:][path]filename1 filename2
```
**Examples:**
```
REN *.txt *.bak                   - Change extension
REN oldname newname                - Rename file
```

### XCOPY - Extended Copy
```
XCOPY source [destination] [/A] [/C] [/D:date] [/E] [/F] [/H] [/I] [/K] [/L] [/M] [/N] [/O] [/P] [/Q] [/R] [/S] [/T] [/U] [/V] [/W] [/X] [/Y] [/Z]
```
**Examples:**
```
XCOPY folder1 folder2 /E /I        - Copy entire directory
XCOPY /S /I source\*.* dest\      - Copy with structure
```

### ROBOCOPY - Robust File Copy
```
ROBOCOPY source destination [file(s)] [options]
```
**Examples:**
```
ROBOCOPY C:\src D:\dst /MIR       - Mirror directories
ROBOCOPY /E /XO source dest       - Copy excluding old files
```

## Directory Operations

### CD/CHDIR - Change Directory
```
CD [/D] [drive:][path]
CHDIR [/D] [drive:][path]
```
**Examples:**
```
CD ..                             - Go to parent directory
CD \folder\subfolder              - Go to specific path
```

### MD/MKDIR - Make Directory
```
MD [drive:]path
MKDIR [drive:]path
```
**Examples:**
```
MD newfolder                      - Create single directory
MD folder1 folder2 folder3        - Create multiple directories
```

### RD/RMDIR - Remove Directory
```
RD [/S] [/Q] [drive:]path
RMDIR [/S] [/Q] [drive:]path
```
**Examples:**
```
RD emptyfolder                    - Remove empty directory
RD /S folder                      - Remove with subdirectories
RD /S /Q folder                  - Quiet remove
```

### PUSHD/POPD - Directory Stack
```
PUSHD [path]
POPD
```
**Examples:**
```
PUSHD C:\folder                   - Save and change directory
POPD                              - Return to previous directory
```

## System Commands

### ATTRIB - Display/Change File Attributes
```
ATTRIB [+attribute|-attribute] [filename] [/S] [/D]
```
**Attributes:** H (Hidden), R (Read-only), S (System), A (Archive)
**Examples:**
```
ATTRIB +H file.txt                - Hide file
ATTRIB -R *.txt /S                - Remove read-only from all txt
```

### FIND - Search for Text
```
FIND [/V] [/C] [/N] "string" [drive:][path]filename
```
**Examples:**
```
FIND "error" log.txt              - Find string in file
FIND /I "case insensitive" file   - Case insensitive search
```

### FINDSTR - Advanced Search
```
FINDSTR [/X] [/I] [/S] "pattern" [files]
```
**Examples:**
```
FINDSTR "error\|warning" *.log   - Multiple patterns
FINDSTR /S /I "text" *.*          - Recursive case-insensitive
```

### TYPE - Display File Contents
```
TYPE [drive:][path]filename
```
**Examples:**
```
TYPE file.txt                     - Display file contents
TYPE file1.txt file2.txt         - Display multiple files
```

### MORE - Display Output One Screen
```
MORE [/E] [/C] [/P] [/S] [files]
command | MORE [/E] [/C] [/P] [/S]
```
**Examples:**
```
TYPE longfile.txt | MORE          - Paginate long output
```

### SORT - Sort Input
```
SORT [/R] [/+n] [/M kilobytes] [/L locale] [/REC recordbytes] [[drive1:][path1]filename1] [/T [drive2:][path2]] [/O [drive3:][path3]filename3]
```
**Examples:**
```
TYPE file.txt | SORT              - Sort alphabetically
DIR | SORT /+2 /R                - Sort by second column, reverse
```

## Batch Script Commands

### ECHO - Display Messages
```
ECHO [ON|OFF]
ECHO [message]
```
**Examples:**
```
ECHO Hello World                  - Display message
ECHO OFF                          - Disable command echoing
ECHO.                             - Empty line
```

### SET - Display/Set Variables
```
SET [variable=[string]]
SET /A expression
SET /P variable=[promptstring]
```
**Examples:**
```
SET name=value                    - Set variable
SET /A num=5+3                   - Arithmetic
SET /P name=Enter name:           - User input
SET PATH                          - Display PATH variable
```

### IF - Conditional Processing
```
IF [NOT] ERRORLEVEL number command
IF [NOT] string1==string2 command
IF [NOT] EXIST filename command
IF [/I] string1 compare-op string2 command
```
**Examples:**
```
IF EXIST file.txt ECHO Found      - Check file existence
IF %ERRORLEVEL% NEQ 0 ECHO Error  - Check error level
IF /I "%var%"=="yes" GOTO yes     - Case insensitive compare
```

### FOR - Loop Commands
```
FOR %variable IN (set) DO command [command-parameters]
FOR /D %variable IN (set) DO command
FOR /R [[drive:]path] %variable IN (set) DO command
FOR /L %variable IN (start,step,end) DO command
FOR /F ["options"] %variable IN (file-set) DO command
```
**Examples:**
```
FOR %f IN (*.txt) DO ECHO %f     - Process files
FOR /L %i IN (1,1,10) DO ECHO %i - Count 1 to 10
FOR /R %f IN (*.txt) DO ...      - Recursive
```

### GOTO - Jump to Label
```
GOTO :label
```
**Examples:**
```
GOTO :EOF                         - End of file
GOTO :error                       - Jump to error label
```

### CALL - Call Batch Script
```
CALL [drive:][path]filename [batch-parameters]
```
**Examples:**
```
CALL other.bat                    - Call another batch file
CALL :subroutine                  - Call subroutine
```

### START - Start Program
```
START ["title"] [/D path] [/I] [/B] [command/program] [parameters]
```
**Examples:**
```
START notepad.exe file.txt        - Open file in Notepad
START "" /WAIT cmd /K            - New window, keep open
START /MIN cmd /C "command"       - Minimized window
```

### TIMEOUT - Delay Execution
```
TIMEOUT /T seconds [/NOBREAK]
```
**Examples:**
```
TIMEOUT /T 5                      - Wait 5 seconds
TIMEOUT /T 30 /NOBREAK           - Ignore key press
```

## Network Commands

### PING - Test Connection
```
PING [-t] [-a] [-n count] [-l size] [-f] [-i TTL] targetname
```
**Examples:**
```
PING google.com                   - Test connection
PING -t 192.168.1.1              - Continuous ping
PING -n 10 -l 1000 google.com    - 10 packets, 1000 bytes
```

### IPCONFIG - Network Configuration
```
IPCONFIG [/allcompartments] [/all] [/renew [adapter]] [/release [adapter]] [/flushdns] [/displaydns] [/registerdns] [/showclassid adapter] [/setclassid adapter [classid]]
```
**Examples:**
```
IPCONFIG                          - Show IP addresses
IPCONFIG /ALL                     - Full configuration
IPCONFIG /flushdns               - Clear DNS cache
```

### NET USE - Map Network Drive
```
NET USE [devicename | *] [\\computer\share[\password]] [/USER:[domain\]user] [/PERSISTENT:YES]
```
**Examples:**
```
NET USE Z: \\server\share        - Map drive
NET USE * \\server\share /USER:domain\user  - With credentials
```

## Variables Reference

| Variable | Description |
|----------|-------------|
| `%~1` | Expand %1, removing any surrounding quotes |
| `%~f1` | Expand %1 to a fully qualified path |
| `%~d1` | Expand %1 to a drive letter |
| `%~p1` | Expand %1 to a path only |
| `%~n1` | Expand %1 to a file name only |
| `%~x1` | Expand %1 to a file extension only |
| `%~dp1` | Expand %1 to drive + path |
| `%~nx1` | Expand %1 to file name + extension |

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Incorrect function |
| 2 | File not found |
| 3 | Path not found |
| 4 | Access denied |
| 5 | Invalid access code |
| 112 | Disk full |
| 255 | Error |

## Tips

- Use `/Y` switch with COPY, MOVE, etc. to suppress confirmation prompt
- Use `command > file.txt` to redirect output to file
- Use `command >> file.txt` to append output to file
- Use `command1 | command2` to pipe output to another command
- Use `command & command2` to run both commands
- Use `command && command2` to run second only if first succeeds
- Use `command || command2` to run second only if first fails
