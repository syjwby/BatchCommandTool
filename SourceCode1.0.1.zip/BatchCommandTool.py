import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
import json
import shutil
import datetime
import subprocess

class BatchCommandTool:
    def __init__(self, root):
        self.root = root
        self.root.overrideredirect(False)
        self.root.geometry("1000x700")
        self.root.title("Batch Command Tool")

        if getattr(sys, 'frozen', False):
            self.script_dir = sys._MEIPASS
        else:
            self.script_dir = os.path.dirname(os.path.abspath(__file__))
        
        icon_path = os.path.join(self.script_dir, "icon.ico")
        if os.path.exists(icon_path):
            self.root.iconbitmap(default=icon_path)
        self.config_dir = os.path.join(self.script_dir, "config")
        self.language_dir = os.path.join(self.config_dir, "language")
        self.settings_file = os.path.join(self.config_dir, "settings.json")

        os.makedirs(self.config_dir, exist_ok=True)
        os.makedirs(self.language_dir, exist_ok=True)

        self.settings = self.load_settings()
        self.language = self.load_language(self.settings["language"])

        self.create_layout()
        self.create_sidebar_buttons()
        self.show_file_batch()

        self.root.mainloop()

    def detect_system_language(self):
        import locale
        system_lang = locale.getdefaultlocale()[0]
        if system_lang:
            if system_lang.startswith("zh"):
                return "zh_cn"
            elif system_lang.startswith("fr"):
                return "fr_fr"
            elif system_lang.startswith("es"):
                return "es_es"
            elif system_lang.startswith("ru"):
                return "ru_ru"
            elif system_lang.startswith("ar"):
                return "ar_ar"
        return "en_us"

    def get_available_languages(self):
        if not os.path.exists(self.language_dir):
            return ["en_us"]
        files = [f for f in os.listdir(self.language_dir) if f.endswith('.json')]
        langs = [f[:-5] for f in files]
        return langs if langs else ["en_us"]

    def load_settings(self):
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {
            "language": self.detect_system_language(),
            "skip_failed_operations": True,
            "show_error_summary": True
        }

    def save_settings(self):
        try:
            with open(self.settings_file, 'w', encoding='utf-8') as f:
                json.dump(self.settings, f, indent=4, ensure_ascii=False)
        except Exception as e:
            print(f"Failed to save settings: {e}")

    def load_language(self, lang_code):
        lang_file = os.path.join(self.language_dir, f"{lang_code}.json")
        default_file = os.path.join(self.language_dir, "en_us.json")
        try:
            if os.path.exists(lang_file):
                with open(lang_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            elif os.path.exists(default_file):
                with open(default_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except:
            pass
        return self.get_default_language()

    def get_default_language(self):
        return {
            "language_name": "English",
            "app_title": "Batch Command Tool",
            "sidebar": {
                "file_batch": "File\nBatch",
                "cmd_batch": "CMD\nBatch",
                "powershell_batch": "PowerShell\nBatch",
                "settings": "Settings"
            },
            "settings": {
                "title": "Settings",
                "language": "Language",
                "skip_failed": "Skip failed operations automatically",
                "show_summary": "Show error summary after operation"
            },
            "file_batch": {
                "select_folder": "Select Folder",
                "refresh": "Refresh",
                "no_folder": "No folder selected",
                "sort": {
                    "label": "Sort by",
                    "name": "By Name",
                    "size": "By Size",
                    "time": "By Time",
                    "ext": "By Type"
                },
                "actions": {
                    "label": "Batch Actions",
                    "move": "Move to...",
                    "copy": "Copy to...",
                    "copy_here": "Copy Here",
                    "delete": "Delete",
                    "remove": "Remove from List",
                    "rename": "Rename",
                    "change_ext": "Change Extension",
                    "change_time": "Change Time"
                },
                "rename": {
                    "title": "Batch Rename",
                    "select_mode": "Select Rename Mode:",
                    "options": "Options",
                    "preview": "Preview (Original -> New)",
                    "mode": {
                        "simple": "Simple Numbering",
                        "placeholder": "Variable Placeholder",
                        "multi_replace": "Multi-Position Replace",
                        "replace": "Find & Replace",
                        "regex": "Regular Expression",
                        "case": "Change Case",
                        "timestamp": "Add Timestamp",
                        "insert": "Insert/Delete"
                    },
                    "multi_replace": {
                        "label": "Replacement Rules:",
                        "add_rule": "Add Rule",
                        "remove_rule": "Remove",
                        "find": "Find",
                        "replace_with": "Replace",
                        "empty_rules": "Please add at least one rule"
                    },
                    "simple": {"prefix": "Prefix:", "start_num": "Start:", "pad_length": "Padding:"},
                    "placeholder": {"pattern": "Pattern:", "start_num": "Start:", "pad_length": "Padding:"},
                    "replace": {"old": "Find:", "new": "Replace:"},
                    "regex": {"pattern": "Pattern:", "replace": "Replace:"},
                    "case": {"upper": "UPPERCASE", "lower": "lowercase", "title": "Title Case", "capitalize": "Capitalize"},
                    "timestamp": {"format": "Format:", "position": "Position:", "prefix": "Prefix", "suffix": "Suffix"},
                    "insert": {"position": "Position:", "delete_mode": "Delete Mode", "text": "Text/Length:", "delete_length": "Delete Length:"},
                    "format_options": {"full": "YYYYMMDD_HHMMSS", "full_dash": "YYYY-MM-DD_HH-MM-SS", "date": "YYYYMMDD", "time_only": "HHMMSS"}
                },
                "change_ext": {
                    "title": "Change Extension",
                    "old": "Old Extension:",
                    "new": "New Extension:",
                    "tip_old_empty": "Empty old extension changes all files",
                    "tip_old_has_value": "With old extension, only matching files change"
                },
                "change_time": {
                    "title": "Change Time",
                    "select": "Select New Time:",
                    "year": "Year:", "month": "Month:", "day": "Day:",
                    "hour": "Hour:", "minute": "Min:", "second": "Sec:"
                },
                "confirm": {
                    "delete": "Delete {0} files? This cannot be undone!",
                    "remove": "Remove {0} files from list? They will be restored on refresh."
                },
                "success": {
                    "move": "Moved {0} files", "copy": "Copied {0} files", "copy_here": "Created {0} copies",
                    "delete": "Deleted {0} files", "remove": "Removed {0} files",
                    "rename": "Renamed {0} files", "change_ext": "Changed {0} files", "change_time": "Changed {0} files"
                },
                "error": {
                    "select_files": "Please select files first",
                    "move": "Move failed: {0}", "copy": "Copy failed: {0}", "delete": "Delete failed: {0}",
                    "rename": "Rename failed: {0}", "change_ext": "Change failed: {0}", "change_time": "Change failed: {0}",
                    "load_files": "Load failed: {0}"
                }
            },
            "cmd_batch": {
                "title": "CMD Batch",
                "select_folder": "Select Folder",
                "current_folder": "Folder:",
                "no_folder": "No folder selected",
                "command_input": "Command:",
                "add_command": "Add",
                "command_list": "Commands",
                "execute": "Execute",
                "clear": "Clear",
                "clear_output": "Clear Output",
                "output": "Output",
                "running": "Running...",
                "completed": "Completed",
                "success": "Success",
                "failed": "Failed",
                "error": "Error:",
                "exit_code": "Exit Code:",
                "confirm_execute": "Execute {0} commands?",
                "no_commands": "Please add commands first",
                "no_folder": "Please select a folder first",
                "select_folder_tip": "Select working directory",
                "command_placeholder": "Enter command, e.g.: dir",
                "select_all": "Select All",
                "deselect_all": "Deselect",
                "remove_selected": "Remove Selected"
            }
        }

    def create_layout(self):
        self.main_frame = tk.Frame(self.root, bg="#ecf0f1")
        self.main_frame.pack(side="top", fill="both", expand=True)

        self.sidebar = tk.Frame(self.main_frame, bg="#2c3e50", width=200)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        self.content = tk.Frame(self.main_frame, bg="#ecf0f1")
        self.content.pack(side="right", fill="both", expand=True)

        self.buttons = []

    def create_sidebar_buttons(self):
        if hasattr(self, 'buttons') and self.buttons:
            for btn in self.buttons:
                btn.destroy()

        buttons_data = [
            (self.language["sidebar"]["file_batch"], self.show_file_batch),
            (self.language["sidebar"]["cmd_batch"], self.show_cmd_batch),
            (self.language["sidebar"]["powershell_batch"], self.show_powershell_batch),
            (self.language["sidebar"]["settings"], self.show_settings)
        ]

        self.buttons = []
        for text, cmd in buttons_data:
            btn = tk.Button(self.sidebar, text=text, font=("Arial", 10),
                          bg="#34495e", fg="white", bd=0, pady=15,
                          command=lambda c=cmd: self.on_button_click(c))
            btn.pack(fill="x")
            self.buttons.append(btn)

        self.update_button_colors(0)

    def on_button_click(self, cmd):
        for btn in self.buttons:
            btn.config(bg="#34495e")
        self.buttons[self.buttons.index(self.buttons[0]) if cmd == self.show_file_batch else
                   1 if cmd == self.show_cmd_batch else
                   2 if cmd == self.show_powershell_batch else 3].config(bg="#2c3e50")
        cmd()

    def update_button_colors(self, index):
        for i, btn in enumerate(self.buttons):
            btn.config(bg="#2c3e50" if i == index else "#34495e")

    def clear_content(self):
        for widget in self.content.winfo_children():
            widget.destroy()

    def show_file_batch(self):
        self.clear_content()
        self.update_button_colors(0)

        self.current_folder = ""
        self.file_list = []
        self.removed_files = set()

        title = tk.Label(self.content, text=self.language["file_batch"]["select_folder"],
                        font=("Arial", 16, "bold"), bg="#ecf0f1")
        title.pack(pady=10)

        folder_frame = tk.Frame(self.content, bg="#ecf0f1")
        folder_frame.pack(fill="x", padx=20, pady=5)

        self.folder_label = tk.Label(folder_frame, text=self.language["file_batch"]["no_folder"],
                                    font=("Arial", 10), bg="#ecf0f1", fg="#e74c3c")
        self.folder_label.pack(side="left", padx=10)

        tk.Button(folder_frame, text=self.language["file_batch"]["select_folder"],
                 font=("Arial", 9), bg="#3498db", fg="white",
                 relief="flat", command=self.select_folder).pack(side="right")

        tk.Button(folder_frame, text=self.language["file_batch"]["refresh"],
                 font=("Arial", 9), bg="#27ae60", fg="white",
                 relief="flat", command=self.load_files).pack(side="right", padx=5)

        sort_frame = tk.Frame(self.content, bg="#ecf0f1")
        sort_frame.pack(fill="x", padx=20, pady=5)

        tk.Label(sort_frame, text=self.language["file_batch"]["sort"]["label"],
                font=("Arial", 10), bg="#ecf0f1").pack(side="left")

        self.sort_var = tk.StringVar(value=self.language["file_batch"]["sort"]["name"])
        sort_combo = ttk.Combobox(sort_frame, textvariable=self.sort_var,
                                 values=[
                                     self.language["file_batch"]["sort"]["name"],
                                     self.language["file_batch"]["sort"]["size"],
                                     self.language["file_batch"]["sort"]["time"],
                                     self.language["file_batch"]["sort"]["ext"]
                                 ], state="readonly", width=15)
        sort_combo.pack(side="left", padx=10)
        sort_combo.bind("<<ComboboxSelected>>", lambda e: self.load_files())

        list_frame = tk.Frame(self.content, bg="#ecf0f1")
        list_frame.pack(fill="both", expand=True, padx=20, pady=5)

        self.file_listbox = tk.Listbox(list_frame, font=("Arial", 10),
                                      selectmode="extended")
        self.file_listbox.pack(side="left", fill="both", expand=True)

        scroll_y = tk.Scrollbar(list_frame, orient="vertical", command=self.file_listbox.yview)
        scroll_y.pack(side="right", fill="y")
        self.file_listbox.config(yscrollcommand=scroll_y.set)

        scroll_x = tk.Scrollbar(list_frame, orient="horizontal", command=self.file_listbox.xview)
        scroll_x.pack(side="bottom", fill="x")
        self.file_listbox.config(xscrollcommand=scroll_x.set)

        self.file_listbox.bind("<Button-1>", self.start_drag)
        self.file_listbox.bind("<B1-Motion>", self.do_drag)

        actions_frame = tk.LabelFrame(self.content, text=self.language["file_batch"]["actions"]["label"],
                                     font=("Arial", 10, "bold"), bg="#ecf0f1")
        actions_frame.pack(fill="x", padx=20, pady=10)

        actions = [
            (self.language["file_batch"]["actions"]["move"], self.move_files),
            (self.language["file_batch"]["actions"]["copy"], self.copy_files),
            (self.language["file_batch"]["actions"]["copy_here"], self.copy_here),
            (self.language["file_batch"]["actions"]["delete"], self.delete_files),
            (self.language["file_batch"]["actions"]["remove"], self.remove_from_list),
            (self.language["file_batch"]["actions"]["rename"], self.rename_files),
            (self.language["file_batch"]["actions"]["change_ext"], self.change_extension),
            (self.language["file_batch"]["actions"]["change_time"], self.change_time)
        ]

        for i, (text, cmd) in enumerate(actions):
            row = i // 4
            col = i % 4
            btn = tk.Button(actions_frame, text=text, font=("Arial", 9),
                          bg="#3498db", fg="white", relief="flat",
                          command=cmd)
            btn.grid(row=row, column=col, padx=5, pady=5, sticky="ew")

        actions_frame.columnconfigure(0, weight=1)
        actions_frame.columnconfigure(1, weight=1)
        actions_frame.columnconfigure(2, weight=1)
        actions_frame.columnconfigure(3, weight=1)

    def select_folder(self):
        folder = filedialog.askdirectory()
        if folder:
            self.current_folder = folder
            self.folder_label.config(text=folder, fg="#27ae60")
            self.removed_files.clear()
            self.load_files()

    def load_files(self):
        if not self.current_folder:
            return

        self.file_listbox.delete(0, tk.END)
        self.file_list = []

        try:
            files = os.listdir(self.current_folder)
            files = [f for f in files if f not in self.removed_files and os.path.isfile(os.path.join(self.current_folder, f))]

            sort_type = self.sort_var.get()
            sort_name = self.language["file_batch"]["sort"]["name"]
            sort_size = self.language["file_batch"]["sort"]["size"]
            sort_time = self.language["file_batch"]["sort"]["time"]
            sort_ext = self.language["file_batch"]["sort"]["ext"]

            if sort_type == sort_size:
                files.sort(key=lambda f: os.path.getsize(os.path.join(self.current_folder, f)))
            elif sort_type == sort_time:
                files.sort(key=lambda f: os.path.getmtime(os.path.join(self.current_folder, f)), reverse=True)
            elif sort_type == sort_ext:
                files.sort(key=lambda f: os.path.splitext(f)[1].lower())
            else:
                files.sort(key=lambda f: f.lower())

            self.file_list = files
            for f in files:
                self.file_listbox.insert(tk.END, f)

        except Exception as e:
            messagebox.showerror("Error", self.language["file_batch"]["error"]["load_files"].format(str(e)))

    def start_drag(self, event):
        self.drag_index = self.file_listbox.nearest(event.y)

    def do_drag(self, event):
        pass

    def get_selected_files(self):
        selection = self.file_listbox.curselection()
        if not selection:
            messagebox.showwarning("Warning", self.language["file_batch"]["error"]["select_files"])
            return []
        return [self.file_list[i] for i in selection]

    def move_files(self):
        files = self.get_selected_files()
        if not files:
            return
        dest = filedialog.askdirectory()
        if not dest:
            return
        try:
            count = 0
            for f in files:
                src = os.path.join(self.current_folder, f)
                dst = os.path.join(dest, f)
                if os.path.exists(dst):
                    base, ext = os.path.splitext(f)
                    counter = 1
                    while os.path.exists(dst):
                        dst = os.path.join(dest, f"{base}_{counter}{ext}")
                        counter += 1
                shutil.move(src, dst)
                count += 1
            messagebox.showinfo("Success", self.language["file_batch"]["success"]["move"].format(count))
            self.load_files()
        except Exception as e:
            messagebox.showerror("Error", self.language["file_batch"]["error"]["move"].format(str(e)))

    def copy_files(self):
        files = self.get_selected_files()
        if not files:
            return
        dest = filedialog.askdirectory()
        if not dest:
            return
        try:
            count = 0
            for f in files:
                src = os.path.join(self.current_folder, f)
                dst = os.path.join(dest, f)
                if os.path.exists(dst):
                    base, ext = os.path.splitext(f)
                    counter = 1
                    while os.path.exists(dst):
                        dst = os.path.join(dest, f"{base}_{counter}{ext}")
                        counter += 1
                shutil.copy2(src, dst)
                count += 1
            messagebox.showinfo("Success", self.language["file_batch"]["success"]["copy"].format(count))
        except Exception as e:
            messagebox.showerror("Error", self.language["file_batch"]["error"]["copy"].format(str(e)))

    def copy_here(self):
        files = self.get_selected_files()
        if not files:
            return
        try:
            count = 0
            for f in files:
                src = os.path.join(self.current_folder, f)
                base, ext = os.path.splitext(f)
                new_name = f"{base}_副本{ext}"
                dst = os.path.join(self.current_folder, new_name)
                counter = 1
                while os.path.exists(dst):
                    new_name = f"{base}_副本{counter}{ext}"
                    dst = os.path.join(self.current_folder, new_name)
                    counter += 1
                shutil.copy2(src, dst)
                count += 1
            messagebox.showinfo("Success", self.language["file_batch"]["success"]["copy_here"].format(count))
            self.load_files()
        except Exception as e:
            messagebox.showerror("Error", self.language["file_batch"]["error"]["copy"].format(str(e)))

    def delete_files(self):
        files = self.get_selected_files()
        if not files:
            return
        result = messagebox.askyesno("Confirm", self.language["file_batch"]["confirm"]["delete"].format(len(files)))
        if not result:
            return
        try:
            count = 0
            for f in files:
                src = os.path.join(self.current_folder, f)
                os.remove(src)
                count += 1
            messagebox.showinfo("Success", self.language["file_batch"]["success"]["delete"].format(count))
            self.load_files()
        except Exception as e:
            messagebox.showerror("Error", self.language["file_batch"]["error"]["delete"].format(str(e)))

    def remove_from_list(self):
        selection = self.file_listbox.curselection()
        if not selection:
            return
        result = messagebox.askyesno("Confirm",
            self.language["file_batch"]["confirm"]["remove"].format(len(selection)))
        if not result:
            return
        for i in reversed(selection):
            self.removed_files.add(self.file_list[i])
            self.file_listbox.delete(i)

    def rename_files(self):
        files = self.get_selected_files()
        if not files:
            return

        rename_window = tk.Toplevel(self.root)
        rename_window.title(self.language["file_batch"]["rename"]["title"])
        rename_window.geometry("800x600")
        rename_window.transient(self.root)

        main_frame = tk.Frame(rename_window)
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=380)
        left_frame.pack(side="left", fill="both", expand=True)

        right_frame = tk.Frame(main_frame, width=380)
        right_frame.pack(side="right", fill="both", expand=True)

        tk.Label(left_frame, text=self.language["file_batch"]["rename"]["select_mode"],
                font=("Arial", 10, "bold")).pack(anchor="w", pady=5)

        mode_var = tk.StringVar(value="simple")
        modes = [
            (self.language["file_batch"]["rename"]["mode"]["simple"], "simple"),
            (self.language["file_batch"]["rename"]["mode"]["placeholder"], "placeholder"),
            (self.language["file_batch"]["rename"]["mode"]["multi_replace"], "multi_replace"),
            (self.language["file_batch"]["rename"]["mode"]["replace"], "replace"),
            (self.language["file_batch"]["rename"]["mode"]["regex"], "regex"),
            (self.language["file_batch"]["rename"]["mode"]["case"], "case"),
            (self.language["file_batch"]["rename"]["mode"]["timestamp"], "timestamp"),
            (self.language["file_batch"]["rename"]["mode"]["insert"], "insert")
        ]
        for text, value in modes:
            tk.Radiobutton(left_frame, text=text, variable=mode_var, value=value,
                         font=("Arial", 9)).pack(anchor="w")

        options_frame = tk.LabelFrame(left_frame, text=self.language["file_batch"]["rename"]["options"],
                                     font=("Arial", 10, "bold"))
        options_frame.pack(fill="both", expand=True, pady=5)

        button_frame = tk.Frame(left_frame)
        button_frame.pack(fill="x", pady=5)

        tk.Label(right_frame, text=self.language["file_batch"]["rename"]["preview"],
                font=("Arial", 10, "bold")).pack(anchor="w", pady=5)

        preview_frame = tk.Frame(right_frame, bg="#f0f0f0", relief="sunken", bd=2)
        preview_frame.pack(fill="both", expand=True)

        preview_list = tk.Listbox(preview_frame, font=("Arial", 9))
        preview_list.pack(fill="both", expand=True)

        widgets = {}

        def update_preview():
            preview_list.delete(0, tk.END)
            mode = mode_var.get()
            for i, filename in enumerate(files):
                name_part, ext = os.path.splitext(filename)
                try:
                    if mode == "simple":
                        prefix = widgets.get("simple_prefix", tk.Entry()).get() or "file"
                        start_num = int(widgets.get("simple_start", tk.Spinbox()).get() or "1")
                        pad_length = int(widgets.get("simple_pad", tk.Spinbox()).get() or "3")
                        new_name = f"{prefix}{str(start_num + i).zfill(pad_length)}{ext}"
                    elif mode == "placeholder":
                        pattern = widgets.get("placeholder_pattern", tk.Entry()).get() or "{name}_{num}{ext}"
                        start_num = int(widgets.get("placeholder_start", tk.Spinbox()).get() or "1")
                        pad_length = int(widgets.get("placeholder_pad", tk.Spinbox()).get() or "3")
                        new_name = pattern.format(
                            name=name_part, num=str(start_num + i).zfill(pad_length),
                            index=i, index1=i+1, ext=ext, ext_no_dot=ext[1:] if ext else "")
                    elif mode == "multi_replace":
                        rules_list = widgets.get("multi_rules_list", [])
                        new_name_part = name_part
                        for _, find_entry, replace_entry in rules_list:
                            find_text = find_entry.get()
                            replace_text = replace_entry.get()
                            if find_text:
                                new_name_part = new_name_part.replace(find_text, replace_text)
                        new_name = new_name_part + ext
                    elif mode == "replace":
                        old_text = widgets.get("replace_old", tk.Entry()).get()
                        new_text = widgets.get("replace_new", tk.Entry()).get()
                        new_name = name_part.replace(old_text, new_text) + ext
                    elif mode == "regex":
                        import re
                        pattern = widgets.get("regex_pattern", tk.Entry()).get()
                        replace = widgets.get("regex_replace", tk.Entry()).get()
                        new_name = re.sub(pattern, replace, name_part) + ext
                    elif mode == "case":
                        case_mode = widgets.get("case_mode", tk.StringVar()).get()
                        if case_mode == "upper":
                            new_name = name_part.upper() + ext
                        elif case_mode == "lower":
                            new_name = name_part.lower() + ext
                        elif case_mode == "title":
                            new_name = name_part.title() + ext
                        else:
                            new_name = name_part.capitalize() + ext
                    elif mode == "timestamp":
                        fmt = widgets.get("timestamp_format", tk.StringVar()).get()
                        timestamp = datetime.datetime.now().strftime(fmt)
                        position = widgets.get("timestamp_position", tk.StringVar()).get()
                        new_name = f"{timestamp}_{name_part}{ext}" if position == "prefix" else f"{name_part}_{timestamp}{ext}"
                    elif mode == "insert":
                        text = widgets.get("insert_text", tk.Entry()).get()
                        position = int(widgets.get("insert_pos", tk.Spinbox()).get() or "0")
                        is_delete = widgets.get("insert_delete", tk.BooleanVar()).get()
                        if is_delete:
                            delete_len = int(widgets.get("insert_delete_len", tk.Spinbox()).get() or "1")
                            new_name = name_part[:position] + name_part[position+delete_len:] + ext if position < len(name_part) else name_part + ext
                        else:
                            new_name = name_part[:position] + text + name_part[position:] + ext if position < len(name_part) else name_part + text + ext
                    else:
                        new_name = filename
                except:
                    new_name = filename
                preview_list.insert(tk.END, f"{filename:<30} -> {new_name}")

        def clear_options():
            for widget in options_frame.winfo_children():
                widget.destroy()
            widgets.clear()

        def on_mode_change(*args):
            clear_options()
            mode = mode_var.get()

            if mode == "simple":
                tk.Label(options_frame, text=self.language["file_batch"]["rename"]["simple"]["prefix"], font=("Arial", 9)).pack(anchor="w")
                entry = tk.Entry(options_frame, font=("Arial", 10))
                entry.insert(0, "file")
                entry.pack(fill="x", pady=2)
                widgets["simple_prefix"] = entry

                tk.Label(options_frame, text=self.language["file_batch"]["rename"]["simple"]["start_num"], font=("Arial", 9)).pack(anchor="w")
                start_spin = tk.Spinbox(options_frame, from_=1, to=99999, font=("Arial", 10))
                start_spin.pack(fill="x", pady=2)
                widgets["simple_start"] = start_spin

                tk.Label(options_frame, text=self.language["file_batch"]["rename"]["simple"]["pad_length"], font=("Arial", 9)).pack(anchor="w")
                pad_spin = tk.Spinbox(options_frame, from_=1, to=10, font=("Arial", 10))
                pad_spin.delete(0, tk.END)
                pad_spin.insert(0, "3")
                pad_spin.pack(fill="x", pady=2)
                widgets["simple_pad"] = pad_spin

            elif mode == "placeholder":
                tk.Label(options_frame, text=self.language["file_batch"]["rename"]["placeholder"]["pattern"], font=("Arial", 9)).pack(anchor="w")
                entry = tk.Entry(options_frame, font=("Arial", 10))
                entry.insert(0, "{name}_{num}{ext}")
                entry.pack(fill="x", pady=2)
                widgets["placeholder_pattern"] = entry

                tk.Label(options_frame, text=self.language["file_batch"]["rename"]["placeholder"]["start_num"], font=("Arial", 9)).pack(anchor="w")
                start_spin = tk.Spinbox(options_frame, from_=1, to=99999, font=("Arial", 10))
                start_spin.pack(fill="x", pady=2)
                widgets["placeholder_start"] = start_spin

                tk.Label(options_frame, text=self.language["file_batch"]["rename"]["placeholder"]["pad_length"], font=("Arial", 9)).pack(anchor="w")
                pad_spin = tk.Spinbox(options_frame, from_=1, to=10, font=("Arial", 10))
                pad_spin.delete(0, tk.END)
                pad_spin.insert(0, "3")
                pad_spin.pack(fill="x", pady=2)
                widgets["placeholder_pad"] = pad_spin

            elif mode == "multi_replace":
                rules_frame = tk.Frame(options_frame)
                rules_frame.pack(fill="both", expand=True)
                widgets["multi_rules_frame"] = rules_frame

                tk.Label(rules_frame, text=self.language["file_batch"]["rename"]["multi_replace"]["label"], font=("Arial", 9)).pack(anchor="w", pady=2)

                rules_container = tk.Frame(rules_frame)
                rules_container.pack(fill="both", expand=True, pady=5)
                widgets["multi_rules_container"] = rules_container

                rules_list = []
                widgets["multi_rules_list"] = rules_list

                def add_rule():
                    rule_frame = tk.Frame(rules_container)
                    rule_frame.pack(fill="x", pady=2)

                    find_entry = tk.Entry(rule_frame, font=("Arial", 9), width=12)
                    find_entry.pack(side="left", padx=2)

                    replace_entry = tk.Entry(rule_frame, font=("Arial", 9), width=12)
                    replace_entry.pack(side="left", padx=2)

                    def remove_this_rule():
                        rule_frame.destroy()
                        rules_list[:] = [r for r in rules_list if r[0] != rule_frame]

                    remove_btn = tk.Button(rule_frame, text=self.language["file_batch"]["rename"]["multi_replace"]["remove_rule"],
                                        font=("Arial", 8), bg="#e74c3c", fg="white", relief="flat", command=remove_this_rule)
                    remove_btn.pack(side="right", padx=2)

                    rules_list.append((rule_frame, find_entry, replace_entry))

                add_btn = tk.Button(rules_frame, text=self.language["file_batch"]["rename"]["multi_replace"]["add_rule"],
                                font=("Arial", 9), bg="#27ae60", fg="white", relief="flat", command=add_rule)
                add_btn.pack(anchor="w", pady=5)
                add_rule()

            elif mode == "replace":
                tk.Label(options_frame, text=self.language["file_batch"]["rename"]["replace"]["old"], font=("Arial", 9)).pack(anchor="w")
                old_entry = tk.Entry(options_frame, font=("Arial", 10))
                old_entry.pack(fill="x", pady=2)
                widgets["replace_old"] = old_entry

                tk.Label(options_frame, text=self.language["file_batch"]["rename"]["replace"]["new"], font=("Arial", 9)).pack(anchor="w")
                new_entry = tk.Entry(options_frame, font=("Arial", 10))
                new_entry.pack(fill="x", pady=2)
                widgets["replace_new"] = new_entry

            elif mode == "regex":
                tk.Label(options_frame, text=self.language["file_batch"]["rename"]["regex"]["pattern"], font=("Arial", 9)).pack(anchor="w")
                pattern_entry = tk.Entry(options_frame, font=("Arial", 10))
                pattern_entry.pack(fill="x", pady=2)
                widgets["regex_pattern"] = pattern_entry

                tk.Label(options_frame, text=self.language["file_batch"]["rename"]["regex"]["replace"], font=("Arial", 9)).pack(anchor="w")
                replace_entry = tk.Entry(options_frame, font=("Arial", 10))
                replace_entry.pack(fill="x", pady=2)
                widgets["regex_replace"] = replace_entry

            elif mode == "case":
                case_var = tk.StringVar(value="upper")
                case_options = [
                    (self.language["file_batch"]["rename"]["case"]["upper"], "upper"),
                    (self.language["file_batch"]["rename"]["case"]["lower"], "lower"),
                    (self.language["file_batch"]["rename"]["case"]["title"], "title"),
                    (self.language["file_batch"]["rename"]["case"]["capitalize"], "capitalize")
                ]
                for text, value in case_options:
                    tk.Radiobutton(options_frame, text=text, variable=case_var, value=value, font=("Arial", 9)).pack(anchor="w")
                widgets["case_mode"] = case_var

            elif mode == "timestamp":
                format_var = tk.StringVar(value="%Y%m%d_%H%M%S")
                formats = [
                    (self.language["file_batch"]["rename"]["format_options"]["full"], "%Y%m%d_%H%M%S"),
                    (self.language["file_batch"]["rename"]["format_options"]["full_dash"], "%Y-%m-%d_%H-%M-%S"),
                    (self.language["file_batch"]["rename"]["format_options"]["date"], "%Y%m%d"),
                    (self.language["file_batch"]["rename"]["format_options"]["time_only"], "%H%M%S")
                ]
                for text, value in formats:
                    tk.Radiobutton(options_frame, text=text, variable=format_var, value=value, font=("Arial", 9)).pack(anchor="w")
                widgets["timestamp_format"] = format_var

                pos_var = tk.StringVar(value="prefix")
                pos_options = [
                    (self.language["file_batch"]["rename"]["timestamp"]["prefix"], "prefix"),
                    (self.language["file_batch"]["rename"]["timestamp"]["suffix"], "suffix")
                ]
                for text, value in pos_options:
                    tk.Radiobutton(options_frame, text=text, variable=pos_var, value=value, font=("Arial", 9)).pack(anchor="w")
                widgets["timestamp_position"] = pos_var

            elif mode == "insert":
                tk.Label(options_frame, text=self.language["file_batch"]["rename"]["insert"]["position"], font=("Arial", 9)).pack(anchor="w")
                pos_spin = tk.Spinbox(options_frame, from_=0, to=999, font=("Arial", 10))
                pos_spin.pack(fill="x", pady=2)
                widgets["insert_pos"] = pos_spin

                delete_var = tk.BooleanVar(value=False)
                tk.Checkbutton(options_frame, text=self.language["file_batch"]["rename"]["insert"]["delete_mode"],
                             variable=delete_var, font=("Arial", 9)).pack(anchor="w")
                widgets["insert_delete"] = delete_var

                tk.Label(options_frame, text=self.language["file_batch"]["rename"]["insert"]["text"], font=("Arial", 9)).pack(anchor="w")
                text_entry = tk.Entry(options_frame, font=("Arial", 10))
                text_entry.pack(fill="x", pady=2)
                widgets["insert_text"] = text_entry

                tk.Label(options_frame, text=self.language["file_batch"]["rename"]["insert"]["delete_length"], font=("Arial", 9)).pack(anchor="w")
                delete_len_spin = tk.Spinbox(options_frame, from_=1, to=999, font=("Arial", 10))
                delete_len_spin.pack(fill="x", pady=2)
                widgets["insert_delete_len"] = delete_len_spin

            for widget in options_frame.winfo_children():
                if hasattr(widget, 'bind'):
                    widget.bind('<KeyRelease>', lambda e: update_preview())
                    widget.bind('<ButtonRelease>', lambda e: update_preview())

            update_preview()

        mode_var.trace('w', on_mode_change)
        on_mode_change()

        def do_rename():
            mode = mode_var.get()
            success_count = 0
            failed_count = 0
            failed_files = []
            skip_failed = self.settings.get("skip_failed_operations", True)
            show_summary = self.settings.get("show_error_summary", True)

            for i, filename in enumerate(files):
                try:
                    name_part, ext = os.path.splitext(filename)

                    if mode == "simple":
                        prefix = widgets.get("simple_prefix", tk.Entry()).get() or "file"
                        start_num = int(widgets.get("simple_start", tk.Spinbox()).get() or "1")
                        pad_length = int(widgets.get("simple_pad", tk.Spinbox()).get() or "3")
                        new_name = f"{prefix}{str(start_num + i).zfill(pad_length)}{ext}"
                    elif mode == "placeholder":
                        pattern = widgets.get("placeholder_pattern", tk.Entry()).get() or "{name}_{num}{ext}"
                        start_num = int(widgets.get("placeholder_start", tk.Spinbox()).get() or "1")
                        pad_length = int(widgets.get("placeholder_pad", tk.Spinbox()).get() or "3")
                        new_name = pattern.format(
                            name=name_part, num=str(start_num + i).zfill(pad_length),
                            index=i, index1=i+1, ext=ext, ext_no_dot=ext[1:] if ext else "")
                    elif mode == "multi_replace":
                        rules_list = widgets.get("multi_rules_list", [])
                        if not rules_list:
                            if skip_failed:
                                failed_files.append(f"{filename}: {self.language['file_batch']['rename']['multi_replace']['empty_rules']}")
                                failed_count += 1
                                continue
                            else:
                                raise ValueError(self.language["file_batch"]["rename"]["multi_replace"]["empty_rules"])
                        new_name_part = name_part
                        for _, find_entry, replace_entry in rules_list:
                            find_text = find_entry.get()
                            replace_text = replace_entry.get()
                            if find_text:
                                new_name_part = new_name_part.replace(find_text, replace_text)
                        new_name = new_name_part + ext
                    elif mode == "replace":
                        old_text = widgets.get("replace_old", tk.Entry()).get()
                        new_text = widgets.get("replace_new", tk.Entry()).get()
                        new_name = name_part.replace(old_text, new_text) + ext
                    elif mode == "regex":
                        import re
                        pattern = widgets.get("regex_pattern", tk.Entry()).get()
                        replace = widgets.get("regex_replace", tk.Entry()).get()
                        try:
                            new_name = re.sub(pattern, replace, name_part) + ext
                        except Exception as re_err:
                            if skip_failed:
                                failed_files.append(f"{filename}: {str(re_err)}")
                                failed_count += 1
                                continue
                            else:
                                raise
                    elif mode == "case":
                        case_mode = widgets.get("case_mode", tk.StringVar()).get()
                        if case_mode == "upper":
                            new_name = name_part.upper() + ext
                        elif case_mode == "lower":
                            new_name = name_part.lower() + ext
                        elif case_mode == "title":
                            new_name = name_part.title() + ext
                        else:
                            new_name = name_part.capitalize() + ext
                    elif mode == "timestamp":
                        fmt = widgets.get("timestamp_format", tk.StringVar()).get()
                        timestamp = datetime.datetime.now().strftime(fmt)
                        position = widgets.get("timestamp_position", tk.StringVar()).get()
                        new_name = f"{timestamp}_{name_part}{ext}" if position == "prefix" else f"{name_part}_{timestamp}{ext}"
                    elif mode == "insert":
                        text = widgets.get("insert_text", tk.Entry()).get()
                        position = int(widgets.get("insert_pos", tk.Spinbox()).get() or "0")
                        is_delete = widgets.get("insert_delete", tk.BooleanVar()).get()
                        if is_delete:
                            delete_len = int(widgets.get("insert_delete_len", tk.Spinbox()).get() or "1")
                            if position < len(name_part):
                                new_name = name_part[:position] + name_part[position+delete_len:] + ext
                            else:
                                if skip_failed:
                                    failed_files.append(f"{filename}: Position out of range")
                                    failed_count += 1
                                    continue
                                else:
                                    raise ValueError("Position out of range")
                        else:
                            new_name = name_part[:position] + text + name_part[position:] + ext if position < len(name_part) else name_part + text + ext
                    else:
                        if skip_failed:
                            failed_files.append(f"{filename}: Unknown mode")
                            failed_count += 1
                            continue
                        else:
                            raise ValueError("Unknown mode")

                    src = os.path.join(self.current_folder, filename)
                    dst = os.path.join(self.current_folder, new_name)

                    if not os.path.exists(src):
                        if skip_failed:
                            failed_files.append(f"{filename}: File not found")
                            failed_count += 1
                            continue
                        else:
                            raise FileNotFoundError(f"File not found: {filename}")

                    if src == dst:
                        if skip_failed:
                            failed_files.append(f"{filename}: Same filename")
                            failed_count += 1
                            continue
                        else:
                            raise ValueError("Source and destination are the same")

                    os.rename(src, dst)
                    success_count += 1

                except Exception as e:
                    if skip_failed:
                        failed_files.append(f"{filename}: {str(e)}")
                        failed_count += 1
                    else:
                        messagebox.showerror("Error", str(e))
                        return

            messagebox.showinfo("Success", self.language["file_batch"]["success"]["rename"].format(success_count))

            if show_summary and failed_count > 0:
                summary_window = tk.Toplevel(self.root)
                summary_window.title("Error Summary")
                summary_window.geometry("500x400")
                summary_window.transient(self.root)

                tk.Label(summary_window, text=f"Failed to process {failed_count} file(s):",
                        font=("Arial", 12, "bold")).pack(pady=10)

                scrollbar = tk.Scrollbar(summary_window)
                scrollbar.pack(side="right", fill="y")

                listbox = tk.Listbox(summary_window, font=("Arial", 10), yscrollcommand=scrollbar.set)
                for failed in failed_files:
                    listbox.insert(tk.END, failed)
                listbox.pack(fill="both", expand=True, padx=10, pady=5)
                scrollbar.config(command=listbox.yview)

                tk.Button(summary_window, text="Close", bg="#27ae60", fg="white",
                        font=("Arial", 10), relief="flat", padx=20, pady=8,
                        command=summary_window.destroy).pack(pady=10)

            rename_window.destroy()
            self.load_files()

        tk.Button(button_frame, text="OK", bg="#27ae60", fg="white",
                 font=("Arial", 10), relief="flat", padx=20, pady=8,
                 command=do_rename).pack(side="left", expand=True)

        tk.Button(button_frame, text="Cancel", bg="#95a5a6", fg="white",
                 font=("Arial", 10), relief="flat", padx=20, pady=8,
                 command=rename_window.destroy).pack(side="right", expand=True)

    def change_extension(self):
        files = self.get_selected_files()
        if not files:
            return

        ext_window = tk.Toplevel(self.root)
        ext_window.title(self.language["file_batch"]["change_ext"]["title"])
        ext_window.geometry("380x280")
        ext_window.transient(self.root)

        info_frame = tk.Frame(ext_window, bg="#f0f8ff", relief="groove", bd=2)
        info_frame.pack(fill="x", padx=10, pady=10)
        tk.Label(info_frame, text=f"💡 {self.language['file_batch']['change_ext']['tip_old_empty']}\n• {self.language['file_batch']['change_ext']['tip_old_has_value']}",
                font=("Arial", 9), bg="#f0f8ff", justify="left").pack(pady=10)

        tk.Label(ext_window, text=self.language["file_batch"]["change_ext"]["old"], font=("Arial", 10)).pack(pady=5)
        old_ext_entry = tk.Entry(ext_window, font=("Arial", 10), width=20)
        old_ext_entry.pack(pady=5)

        tk.Label(ext_window, text=self.language["file_batch"]["change_ext"]["new"], font=("Arial", 10)).pack(pady=5)
        new_ext_entry = tk.Entry(ext_window, font=("Arial", 10), width=20)
        new_ext_entry.pack(pady=5)

        def do_change():
            old_ext = old_ext_entry.get().strip()
            new_ext = new_ext_entry.get().strip()

            if not new_ext:
                messagebox.showwarning("Warning", self.language["file_batch"]["error"]["select_files"])
                return

            if old_ext and not old_ext.startswith('.'):
                old_ext = '.' + old_ext
            if not new_ext.startswith('.'):
                new_ext = '.' + new_ext

            try:
                count = 0
                for filename in files:
                    if old_ext:
                        if filename.lower().endswith(old_ext.lower()):
                            src = os.path.join(self.current_folder, filename)
                            new_name = filename[:-len(old_ext)] + new_ext
                            dst = os.path.join(self.current_folder, new_name)
                            os.rename(src, dst)
                            count += 1
                    else:
                        src = os.path.join(self.current_folder, filename)
                        name_part = os.path.splitext(filename)[0]
                        new_name = name_part + new_ext
                        dst = os.path.join(self.current_folder, new_name)
                        os.rename(src, dst)
                        count += 1

                messagebox.showinfo("Success", self.language["file_batch"]["success"]["change_ext"].format(count))
                ext_window.destroy()
                self.load_files()
            except Exception as e:
                messagebox.showerror("Error", self.language["file_batch"]["error"]["change_ext"].format(str(e)))

        tk.Button(ext_window, text="OK", bg="#27ae60", fg="white",
                 font=("Arial", 10), relief="flat", padx=20, pady=8,
                 command=do_change).pack(pady=10)

    def change_time(self):
        files = self.get_selected_files()
        if not files:
            return

        time_window = tk.Toplevel(self.root)
        time_window.title(self.language["file_batch"]["change_time"]["title"])
        time_window.geometry("350x250")
        time_window.transient(self.root)

        tk.Label(time_window, text=self.language["file_batch"]["change_time"]["select"], font=("Arial", 10)).pack(pady=10)

        time_frame = tk.Frame(time_window)
        time_frame.pack(pady=10)

        now = datetime.datetime.now()
        tk.Label(time_frame, text=self.language["file_batch"]["change_time"]["year"], font=("Arial", 9)).grid(row=0, column=0)
        year_spin = tk.Spinbox(time_frame, from_=2000, to=2100, width=8, font=("Arial", 9))
        year_spin.grid(row=0, column=1, padx=5)
        year_spin.delete(0, tk.END)
        year_spin.insert(0, str(now.year))

        tk.Label(time_frame, text=self.language["file_batch"]["change_time"]["month"], font=("Arial", 9)).grid(row=0, column=2)
        month_spin = tk.Spinbox(time_frame, from_=1, to=12, width=8, font=("Arial", 9))
        month_spin.grid(row=0, column=3, padx=5)
        month_spin.delete(0, tk.END)
        month_spin.insert(0, str(now.month))

        tk.Label(time_frame, text=self.language["file_batch"]["change_time"]["day"], font=("Arial", 9)).grid(row=0, column=4)
        day_spin = tk.Spinbox(time_frame, from_=1, to=31, width=8, font=("Arial", 9))
        day_spin.grid(row=0, column=5, padx=5)
        day_spin.delete(0, tk.END)
        day_spin.insert(0, str(now.day))

        tk.Label(time_frame, text=self.language["file_batch"]["change_time"]["hour"], font=("Arial", 9)).grid(row=1, column=0, pady=10)
        hour_spin = tk.Spinbox(time_frame, from_=0, to=23, width=8, font=("Arial", 9))
        hour_spin.grid(row=1, column=1, padx=5, pady=10)
        hour_spin.delete(0, tk.END)
        hour_spin.insert(0, str(now.hour))

        tk.Label(time_frame, text=self.language["file_batch"]["change_time"]["minute"], font=("Arial", 9)).grid(row=1, column=2, pady=10)
        minute_spin = tk.Spinbox(time_frame, from_=0, to=59, width=8, font=("Arial", 9))
        minute_spin.grid(row=1, column=3, padx=5, pady=10)
        minute_spin.delete(0, tk.END)
        minute_spin.insert(0, str(now.minute))

        tk.Label(time_frame, text=self.language["file_batch"]["change_time"]["second"], font=("Arial", 9)).grid(row=1, column=4, pady=10)
        second_spin = tk.Spinbox(time_frame, from_=0, to=59, width=8, font=("Arial", 9))
        second_spin.grid(row=1, column=5, padx=5, pady=10)
        second_spin.delete(0, tk.END)
        second_spin.insert(0, str(now.second))

        def do_change_time():
            try:
                year = int(year_spin.get())
                month = int(month_spin.get())
                day = int(day_spin.get())
                hour = int(hour_spin.get())
                minute = int(minute_spin.get())
                second = int(second_spin.get())
                new_time = datetime.datetime(year, month, day, hour, minute, second)
                timestamp = new_time.timestamp()

                count = 0
                for filename in files:
                    src = os.path.join(self.current_folder, filename)
                    os.utime(src, (timestamp, timestamp))
                    count += 1

                messagebox.showinfo("Success", self.language["file_batch"]["success"]["change_time"].format(count))
                time_window.destroy()
                self.load_files()
            except Exception as e:
                messagebox.showerror("Error", self.language["file_batch"]["error"]["change_time"].format(str(e)))

        tk.Button(time_window, text="OK", bg="#27ae60", fg="white",
                 font=("Arial", 10), relief="flat", padx=20, pady=8,
                 command=do_change_time).pack(pady=20)

    def show_cmd_batch(self):
        self.clear_content()
        self.update_button_colors(1)

        self.cmd_working_dir = ""
        self.cmd_selected_files = []

        title = tk.Label(self.content, text=self.language["cmd_batch"]["title"],
                       font=("Arial", 16, "bold"), bg="#ecf0f1")
        title.pack(pady=10)

        top_frame = tk.Frame(self.content, bg="#ecf0f1")
        top_frame.pack(fill="x", padx=20, pady=5)

        left_top = tk.Frame(top_frame, bg="#ecf0f1")
        left_top.pack(side="left", fill="x", expand=True)

        tk.Label(left_top, text=self.language["cmd_batch"]["current_folder"],
                font=("Arial", 10), bg="#ecf0f1").pack(anchor="w")

        self.cmd_folder_label = tk.Label(left_top, text=self.language["cmd_batch"]["no_folder"],
                                        font=("Arial", 10), bg="#ecf0f1", fg="#e74c3c")
        self.cmd_folder_label.pack(anchor="w", pady=2)

        tk.Button(top_frame, text=self.language["cmd_batch"]["select_folder"],
                 font=("Arial", 9), bg="#3498db", fg="white",
                 relief="flat", command=self.select_cmd_folder).pack(side="right", padx=5)

        tk.Button(top_frame, text=self.language["cmd_batch"]["help"],
                 font=("Arial", 9), bg="#e67e22", fg="white",
                 relief="flat", command=self.show_cmd_help).pack(side="right", padx=5)

        var_frame = tk.LabelFrame(self.content, text=self.language["cmd_batch"]["variables"],
                                 font=("Arial", 10, "bold"), bg="#ecf0f1")
        var_frame.pack(fill="x", padx=20, pady=5)

        var_info = tk.Label(var_frame, text=self.language["cmd_batch"]["variables_tip"],
                           font=("Arial", 9), bg="#ecf0f1", fg="#7f8c8d")
        var_info.pack(anchor="w", padx=5, pady=2)

        template_frame = tk.Frame(var_frame, bg="#ecf0f1")
        template_frame.pack(fill="x", padx=5, pady=5)

        tk.Label(template_frame, text=self.language["cmd_batch"]["template"],
                font=("Arial", 9), bg="#ecf0f1").pack(side="left", padx=5)

        self.cmd_template_entry = tk.Entry(template_frame, font=("Consolas", 10), width=60)
        self.cmd_template_entry.insert(0, 'ren "{file}" "{newname}"')
        self.cmd_template_entry.pack(side="left", fill="x", expand=True, padx=5)

        tk.Label(template_frame, text=self.language["cmd_batch"]["new_value"],
                font=("Arial", 9), bg="#ecf0f1").pack(side="left", padx=5)

        self.cmd_new_value_entry = tk.Entry(template_frame, font=("Consolas", 10), width=25)
        self.cmd_new_value_entry.insert(0, '{name}_new{ext}')
        self.cmd_new_value_entry.pack(side="left", padx=5)

        file_select_frame = tk.Frame(var_frame, bg="#ecf0f1")
        file_select_frame.pack(fill="x", padx=5, pady=5)

        tk.Label(file_select_frame, text=self.language["cmd_batch"]["select_files"],
                font=("Arial", 9), bg="#ecf0f1").pack(side="left", padx=5)

        tk.Button(file_select_frame, text=self.language["cmd_batch"]["load_files"],
                 font=("Arial", 8), bg="#27ae60", fg="white",
                 relief="flat", command=self.load_cmd_files).pack(side="left", padx=5)

        self.cmd_file_count_label = tk.Label(file_select_frame, text="0 files",
                                            font=("Arial", 9), bg="#ecf0f1", fg="#e74c3c")
        self.cmd_file_count_label.pack(side="left", padx=5)

        list_frame = tk.LabelFrame(self.content, text=self.language["cmd_batch"]["preview"],
                                  font=("Arial", 10, "bold"), bg="#ecf0f1")
        list_frame.pack(fill="both", expand=True, padx=20, pady=5)

        self.cmd_preview_listbox = tk.Listbox(list_frame, font=("Consolas", 9),
                                             height=6)
        self.cmd_preview_listbox.pack(side="left", fill="both", expand=True, padx=5, pady=5)

        cmd_scroll_y = tk.Scrollbar(list_frame, orient="vertical", command=self.cmd_preview_listbox.yview)
        cmd_scroll_y.pack(side="right", fill="y")
        self.cmd_preview_listbox.config(yscrollcommand=cmd_scroll_y.set)

        preview_btn_frame = tk.Frame(list_frame, bg="#ecf0f1")
        preview_btn_frame.pack(fill="x", padx=5, pady=2)

        tk.Button(preview_btn_frame, text=self.language["cmd_batch"]["generate"],
                 font=("Arial", 9), bg="#9b59b6", fg="white",
                 relief="flat", command=self.generate_cmd_preview).pack(side="left", padx=2)

        self.cmd_template_entry.bind("<KeyRelease>", lambda e: self.generate_cmd_preview())
        self.cmd_new_value_entry.bind("<KeyRelease>", lambda e: self.generate_cmd_preview())

        output_frame = tk.LabelFrame(self.content, text=self.language["cmd_batch"]["output"],
                                    font=("Arial", 10, "bold"), bg="#ecf0f1")
        output_frame.pack(fill="both", expand=True, padx=20, pady=5)

        self.cmd_output = tk.Text(output_frame, font=("Consolas", 9),
                                 bg="#2c3e50", fg="#ecf0f1", wrap="none",
                                 state="disabled", height=8)
        self.cmd_output.pack(side="left", fill="both", expand=True, padx=5, pady=5)

        output_scroll_y = tk.Scrollbar(output_frame, orient="vertical", command=self.cmd_output.yview)
        output_scroll_y.pack(side="right", fill="y")
        self.cmd_output.config(yscrollcommand=output_scroll_y.set)

        output_btn_frame = tk.Frame(output_frame, bg="#ecf0f1")
        output_btn_frame.pack(fill="x", padx=5, pady=2)

        tk.Button(output_btn_frame, text=self.language["cmd_batch"]["execute"],
                 font=("Arial", 10), bg="#27ae60", fg="white",
                 relief="flat", padx=20, command=self.execute_cmd_batch).pack(side="left", padx=5)

        tk.Button(output_btn_frame, text=self.language["cmd_batch"]["clear_output"],
                 font=("Arial", 9), bg="#e74c3c", fg="white",
                 relief="flat", command=self.clear_cmd_output).pack(side="right", padx=5)

    def select_cmd_folder(self):
        folder = filedialog.askdirectory(title=self.language["cmd_batch"]["select_folder_tip"])
        if folder:
            self.cmd_working_dir = folder
            self.cmd_folder_label.config(text=folder, fg="#27ae60")
            self.load_cmd_files()

    def load_cmd_files(self):
        if not self.cmd_working_dir:
            return
        try:
            files = os.listdir(self.cmd_working_dir)
            self.cmd_selected_files = [f for f in files if os.path.isfile(os.path.join(self.cmd_working_dir, f))]
            self.cmd_file_count_label.config(text=f"{len(self.cmd_selected_files)} files", fg="#27ae60")
            self.generate_cmd_preview()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def generate_cmd_preview(self):
        self.cmd_preview_listbox.delete(0, tk.END)
        if not self.cmd_selected_files:
            return

        template = self.cmd_template_entry.get()
        new_value = self.cmd_new_value_entry.get()

        for i, filename in enumerate(self.cmd_selected_files[:20]):
            name_part, ext = os.path.splitext(filename)

            cmd = template
            cmd = cmd.replace('{file}', f'"{filename}"')
            cmd = cmd.replace('{name}', name_part)
            cmd = cmd.replace('{ext}', ext)
            cmd = cmd.replace('{index}', str(i))
            cmd = cmd.replace('{index1}', str(i + 1))
            cmd = cmd.replace('{newname}', new_value.replace('{name}', name_part).replace('{ext}', ext).replace('{index}', str(i)).replace('{index1}', str(i + 1)))

            self.cmd_preview_listbox.insert(tk.END, f"[{i+1}] {cmd}")

        if len(self.cmd_selected_files) > 20:
            self.cmd_preview_listbox.insert(tk.END, f"... and {len(self.cmd_selected_files) - 20} more")

    def execute_cmd_batch(self):
        if not self.cmd_working_dir:
            messagebox.showwarning("Warning", self.language["cmd_batch"]["no_folder"])
            return

        template = self.cmd_template_entry.get()
        new_value = self.cmd_new_value_entry.get()

        if not template:
            messagebox.showwarning("Warning", self.language["cmd_batch"]["no_template"])
            return

        commands = []
        for i, filename in enumerate(self.cmd_selected_files):
            name_part, ext = os.path.splitext(filename)

            cmd = template
            cmd = cmd.replace('{file}', f'"{filename}"')
            cmd = cmd.replace('{name}', name_part)
            cmd = cmd.replace('{ext}', ext)
            cmd = cmd.replace('{index}', str(i))
            cmd = cmd.replace('{index1}', str(i + 1))
            cmd = cmd.replace('{newname}', new_value.replace('{name}', name_part).replace('{ext}', ext).replace('{index}', str(i)).replace('{index1}', str(i + 1)))

            commands.append(cmd)

        if not commands:
            messagebox.showwarning("Warning", self.language["cmd_batch"]["no_commands"])
            return

        result = messagebox.askyesno("Confirm",
            self.language["cmd_batch"]["confirm_execute"].format(len(commands)))
        if not result:
            return

        self.clear_cmd_output()
        self.append_cmd_output(f"{'='*60}\n")
        self.append_cmd_output(f"{self.language['cmd_batch']['running']}\n")
        self.append_cmd_output(f"{'='*60}\n\n")

        success_count = 0
        failed_count = 0

        for i, cmd in enumerate(commands, 1):
            self.append_cmd_output(f"[{i}/{len(commands)}] {cmd}\n")
            self.append_cmd_output(f"{'-'*40}\n")

            try:
                result = subprocess.run(
                    cmd,
                    shell=True,
                    cwd=self.cmd_working_dir,
                    capture_output=True,
                    text=True,
                    timeout=30
                )

                if result.stdout:
                    self.append_cmd_output(result.stdout)
                if result.stderr:
                    self.append_cmd_output(f"[STDERR] {result.stderr}")

                if result.returncode == 0:
                    self.append_cmd_output(f"{self.language['cmd_batch']['exit_code']} 0 (Success)\n")
                    success_count += 1
                else:
                    self.append_cmd_output(f"{self.language['cmd_batch']['exit_code']} {result.returncode}\n")
                    failed_count += 1

            except subprocess.TimeoutExpired:
                self.append_cmd_output(f"{self.language['cmd_batch']['error']} Command timeout\n")
                failed_count += 1
            except Exception as e:
                self.append_cmd_output(f"{self.language['cmd_batch']['error']} {str(e)}\n")
                failed_count += 1

            self.append_cmd_output(f"\n")

        self.append_cmd_output(f"{'='*60}\n")
        self.append_cmd_output(f"{self.language['cmd_batch']['completed']}\n")
        self.append_cmd_output(f"{self.language['cmd_batch']['success']}: {success_count}, ")
        self.append_cmd_output(f"{self.language['cmd_batch']['failed']}: {failed_count}\n")
        self.append_cmd_output(f"{'='*60}\n")

        self.load_cmd_files()

    def select_cmd_folder(self):
        folder = filedialog.askdirectory(title=self.language["cmd_batch"]["select_folder_tip"])
        if folder:
            self.cmd_working_dir = folder
            self.cmd_folder_label.config(text=folder, fg="#27ae60")

    def add_cmd_command(self):
        command = self.cmd_entry.get().strip()
        if command:
            self.cmd_listbox.insert(tk.END, command)
            self.cmd_entry.delete(0, tk.END)

    def cmd_select_all(self):
        self.cmd_listbox.select_set(0, tk.END)

    def cmd_deselect_all(self):
        self.cmd_listbox.selection_clear(0, tk.END)

    def cmd_remove_selected(self):
        selected = list(self.cmd_listbox.curselection())
        for index in reversed(selected):
            self.cmd_listbox.delete(index)

    def cmd_clear_list(self):
        self.cmd_listbox.delete(0, tk.END)

    def clear_cmd_output(self):
        self.cmd_output.config(state="normal")
        self.cmd_output.delete(1.0, tk.END)
        self.cmd_output.config(state="disabled")

    def append_cmd_output(self, text):
        self.cmd_output.config(state="normal")
        self.cmd_output.insert(tk.END, text)
        self.cmd_output.see(tk.END)
        self.cmd_output.config(state="disabled")

    def clear_ps_output(self):
        self.ps_output.config(state="normal")
        self.ps_output.delete(1.0, tk.END)
        self.ps_output.config(state="disabled")

    def append_ps_output(self, text):
        self.ps_output.config(state="normal")
        self.ps_output.insert(tk.END, text)
        self.ps_output.see(tk.END)
        self.ps_output.config(state="disabled")

    def show_powershell_batch(self):
        self.clear_content()
        self.update_button_colors(2)

        self.ps_working_dir = ""
        self.ps_selected_files = []

        title = tk.Label(self.content, text=self.language.get("powershell_batch", {}).get("title", "PowerShell Batch"),
                        font=("Arial", 16, "bold"), bg="#ecf0f1")
        title.pack(pady=10)

        top_frame = tk.Frame(self.content, bg="#ecf0f1")
        top_frame.pack(fill="x", padx=20, pady=5)

        left_top = tk.Frame(top_frame, bg="#ecf0f1")
        left_top.pack(side="left", fill="x", expand=True)

        tk.Label(left_top, text=self.language.get("powershell_batch", {}).get("current_folder", "Folder:"),
                font=("Arial", 10), bg="#ecf0f1").pack(anchor="w")

        self.ps_folder_label = tk.Label(left_top, text=self.language.get("powershell_batch", {}).get("no_folder", "No folder selected"),
                                        font=("Arial", 10), bg="#ecf0f1", fg="#e74c3c")
        self.ps_folder_label.pack(anchor="w", pady=2)

        tk.Button(top_frame, text=self.language.get("powershell_batch", {}).get("select_folder", "Select Folder"),
                 font=("Arial", 9), bg="#3498db", fg="white",
                 relief="flat", command=self.select_ps_folder).pack(side="right", padx=5)

        tk.Button(top_frame, text=self.language.get("powershell_batch", {}).get("help", "Help"),
                 font=("Arial", 9), bg="#e67e22", fg="white",
                 relief="flat", command=self.show_ps_help).pack(side="right", padx=5)

        var_frame = tk.LabelFrame(self.content, text=self.language.get("powershell_batch", {}).get("variables", "Variables"),
                                 font=("Arial", 10, "bold"), bg="#ecf0f1")
        var_frame.pack(fill="x", padx=20, pady=5)

        var_info = tk.Label(var_frame, text=self.language.get("powershell_batch", {}).get("variables_tip", "Variables: {file}, {name}, {ext}, {index}, {index1}, {folder}"),
                           font=("Arial", 9), bg="#ecf0f1", fg="#7f8c8d")
        var_info.pack(anchor="w", padx=5, pady=2)

        template_frame = tk.Frame(var_frame, bg="#ecf0f1")
        template_frame.pack(fill="x", padx=5, pady=5)

        tk.Label(template_frame, text=self.language.get("powershell_batch", {}).get("template", "Template:"),
                font=("Arial", 9), bg="#ecf0f1").pack(side="left", padx=5)

        self.ps_template_entry = tk.Entry(template_frame, font=("Consolas", 10), width=60)
        self.ps_template_entry.insert(0, 'Rename-Item -Path "{file}" -NewName "{newname}"')
        self.ps_template_entry.pack(side="left", fill="x", expand=True, padx=5)

        tk.Label(template_frame, text=self.language.get("powershell_batch", {}).get("new_value", "New Value:"),
                font=("Arial", 9), bg="#ecf0f1").pack(side="left", padx=5)

        self.ps_new_value_entry = tk.Entry(template_frame, font=("Consolas", 10), width=25)
        self.ps_new_value_entry.insert(0, '{name}_new{ext}')
        self.ps_new_value_entry.pack(side="left", padx=5)

        file_select_frame = tk.Frame(var_frame, bg="#ecf0f1")
        file_select_frame.pack(fill="x", padx=5, pady=5)

        tk.Label(file_select_frame, text=self.language.get("powershell_batch", {}).get("select_files", "Files:"),
                font=("Arial", 9), bg="#ecf0f1").pack(side="left", padx=5)

        tk.Button(file_select_frame, text=self.language.get("powershell_batch", {}).get("load_files", "Load Files"),
                 font=("Arial", 8), bg="#27ae60", fg="white",
                 relief="flat", command=self.load_ps_files).pack(side="left", padx=5)

        self.ps_file_count_label = tk.Label(file_select_frame, text="0 files",
                                            font=("Arial", 9), bg="#ecf0f1", fg="#e74c3c")
        self.ps_file_count_label.pack(side="left", padx=5)

        list_frame = tk.LabelFrame(self.content, text=self.language.get("powershell_batch", {}).get("preview", "Preview"),
                                  font=("Arial", 10, "bold"), bg="#ecf0f1")
        list_frame.pack(fill="both", expand=True, padx=20, pady=5)

        self.ps_preview_listbox = tk.Listbox(list_frame, font=("Consolas", 9),
                                             height=6)
        self.ps_preview_listbox.pack(side="left", fill="both", expand=True, padx=5, pady=5)

        ps_scroll_y = tk.Scrollbar(list_frame, orient="vertical", command=self.ps_preview_listbox.yview)
        ps_scroll_y.pack(side="right", fill="y")
        self.ps_preview_listbox.config(yscrollcommand=ps_scroll_y.set)

        preview_btn_frame = tk.Frame(list_frame, bg="#ecf0f1")
        preview_btn_frame.pack(fill="x", padx=5, pady=2)

        tk.Button(preview_btn_frame, text=self.language.get("powershell_batch", {}).get("generate", "Generate"),
                 font=("Arial", 9), bg="#9b59b6", fg="white",
                 relief="flat", command=self.generate_ps_preview).pack(side="left", padx=2)

        self.ps_template_entry.bind("<KeyRelease>", lambda e: self.generate_ps_preview())
        self.ps_new_value_entry.bind("<KeyRelease>", lambda e: self.generate_ps_preview())

        output_frame = tk.LabelFrame(self.content, text=self.language.get("powershell_batch", {}).get("output", "Output"),
                                    font=("Arial", 10, "bold"), bg="#ecf0f1")
        output_frame.pack(fill="both", expand=True, padx=20, pady=5)

        self.ps_output = tk.Text(output_frame, font=("Consolas", 9),
                                 bg="#2c3e50", fg="#ecf0f1", wrap="none",
                                 state="disabled", height=8)
        self.ps_output.pack(side="left", fill="both", expand=True, padx=5, pady=5)

        output_scroll_y = tk.Scrollbar(output_frame, orient="vertical", command=self.ps_output.yview)
        output_scroll_y.pack(side="right", fill="y")
        self.ps_output.config(yscrollcommand=output_scroll_y.set)

        output_btn_frame = tk.Frame(output_frame, bg="#ecf0f1")
        output_btn_frame.pack(fill="x", padx=5, pady=2)

        tk.Button(output_btn_frame, text=self.language.get("powershell_batch", {}).get("execute", "Execute"),
                 font=("Arial", 10), bg="#27ae60", fg="white",
                 relief="flat", padx=20, command=self.execute_ps_batch).pack(side="left", padx=5)

        tk.Button(output_btn_frame, text=self.language.get("powershell_batch", {}).get("clear_output", "Clear Output"),
                 font=("Arial", 9), bg="#e74c3c", fg="white",
                 relief="flat", command=self.clear_ps_output).pack(side="right", padx=5)

    def select_ps_folder(self):
        folder = filedialog.askdirectory(title=self.language.get("powershell_batch", {}).get("select_folder_tip", "Select working directory"))
        if folder:
            self.ps_working_dir = folder
            self.ps_folder_label.config(text=folder, fg="#27ae60")
            self.load_ps_files()

    def load_ps_files(self):
        if not self.ps_working_dir:
            return
        try:
            files = os.listdir(self.ps_working_dir)
            self.ps_selected_files = [f for f in files if os.path.isfile(os.path.join(self.ps_working_dir, f))]
            self.ps_file_count_label.config(text=f"{len(self.ps_selected_files)} files", fg="#27ae60")
            self.generate_ps_preview()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def generate_ps_preview(self):
        self.ps_preview_listbox.delete(0, tk.END)
        if not self.ps_selected_files:
            return

        template = self.ps_template_entry.get()
        new_value = self.ps_new_value_entry.get()

        for i, filename in enumerate(self.ps_selected_files[:20]):
            name_part, ext = os.path.splitext(filename)

            cmd = template
            cmd = cmd.replace('{file}', f'"{filename}"')
            cmd = cmd.replace('{name}', name_part)
            cmd = cmd.replace('{ext}', ext)
            cmd = cmd.replace('{index}', str(i))
            cmd = cmd.replace('{index1}', str(i + 1))
            cmd = cmd.replace('{folder}', self.ps_working_dir)
            cmd = cmd.replace('{newname}', new_value.replace('{name}', name_part).replace('{ext}', ext).replace('{index}', str(i)).replace('{index1}', str(i + 1)))

            self.ps_preview_listbox.insert(tk.END, f"[{i+1}] {cmd}")

        if len(self.ps_selected_files) > 20:
            self.ps_preview_listbox.insert(tk.END, f"... and {len(self.ps_selected_files) - 20} more")

    def execute_ps_batch(self):
        if not self.ps_working_dir:
            messagebox.showwarning("Warning", self.language.get("powershell_batch", {}).get("no_folder", "Please select a folder first"))
            return

        template = self.ps_template_entry.get()
        new_value = self.ps_new_value_entry.get()

        if not template:
            messagebox.showwarning("Warning", self.language.get("powershell_batch", {}).get("no_template", "Please enter a template"))
            return

        commands = []
        for i, filename in enumerate(self.ps_selected_files):
            name_part, ext = os.path.splitext(filename)

            cmd = template
            cmd = cmd.replace('{file}', f'"{filename}"')
            cmd = cmd.replace('{name}', name_part)
            cmd = cmd.replace('{ext}', ext)
            cmd = cmd.replace('{index}', str(i))
            cmd = cmd.replace('{index1}', str(i + 1))
            cmd = cmd.replace('{folder}', self.ps_working_dir)
            cmd = cmd.replace('{newname}', new_value.replace('{name}', name_part).replace('{ext}', ext).replace('{index}', str(i)).replace('{index1}', str(i + 1)))

            commands.append(cmd)

        if not commands:
            messagebox.showwarning("Warning", self.language.get("powershell_batch", {}).get("no_commands", "No commands to execute"))
            return

        result = messagebox.askyesno("Confirm",
            self.language.get("powershell_batch", {}).get("confirm_execute", "Execute {0} commands?").format(len(commands)))
        if not result:
            return

        self.clear_ps_output()
        self.append_ps_output(f"{'='*60}\n")
        self.append_ps_output(f"{self.language.get('powershell_batch', {}).get('running', 'Running...')}\n")
        self.append_ps_output(f"{'='*60}\n\n")

        success_count = 0
        failed_count = 0

        for i, cmd in enumerate(commands, 1):
            self.append_ps_output(f"[{i}/{len(commands)}] {cmd}\n")
            self.append_ps_output(f"{'-'*40}\n")

            try:
                ps_command = f'powershell.exe -Command "{cmd}"'
                result = subprocess.run(
                    ps_command,
                    shell=True,
                    cwd=self.ps_working_dir,
                    capture_output=True,
                    text=True,
                    timeout=60
                )

                if result.stdout:
                    self.append_ps_output(result.stdout)
                if result.stderr:
                    self.append_ps_output(f"[STDERR] {result.stderr}")

                if result.returncode == 0:
                    self.append_ps_output(f"{self.language.get('powershell_batch', {}).get('exit_code', 'Exit Code:')} 0 (Success)\n")
                    success_count += 1
                else:
                    self.append_ps_output(f"{self.language.get('powershell_batch', {}).get('exit_code', 'Exit Code:')} {result.returncode}\n")
                    failed_count += 1

            except subprocess.TimeoutExpired:
                self.append_ps_output(f"{self.language.get('powershell_batch', {}).get('error', 'Error:')} Command timeout\n")
                failed_count += 1
            except Exception as e:
                self.append_ps_output(f"{self.language.get('powershell_batch', {}).get('error', 'Error:')} {str(e)}\n")
                failed_count += 1

            self.append_ps_output(f"\n")

        self.append_ps_output(f"{'='*60}\n")
        self.append_ps_output(f"{self.language.get('powershell_batch', {}).get('completed', 'Completed')}\n")
        self.append_ps_output(f"{self.language.get('powershell_batch', {}).get('success', 'Success')}: {success_count}, ")
        self.append_ps_output(f"{self.language.get('powershell_batch', {}).get('failed', 'Failed')}: {failed_count}\n")
        self.append_ps_output(f"{'='*60}\n")

        self.load_ps_files()

    def show_cmd_help(self):
        help_file = os.path.join(self.script_dir, "config", "help", "cmd", f"{self.settings['language']}.md")
        if not os.path.exists(help_file):
            help_file = os.path.join(self.script_dir, "config", "help", "cmd", "en_us.md")

        try:
            with open(help_file, 'r', encoding='utf-8') as f:
                content = f.read()
        except:
            content = "Help file not found."

        self.show_markdown_help("CMD Help", content)

    def show_ps_help(self):
        help_file = os.path.join(self.script_dir, "config", "help", "powershell", f"{self.settings['language']}.md")
        if not os.path.exists(help_file):
            help_file = os.path.join(self.script_dir, "config", "help", "powershell", "en_us.md")

        try:
            with open(help_file, 'r', encoding='utf-8') as f:
                content = f.read()
        except:
            content = "Help file not found."

        self.show_markdown_help("PowerShell Help", content)

    def show_markdown_help(self, title, markdown_content):
        import re

        help_window = tk.Toplevel(self.root)
        help_window.title(title)
        help_window.geometry("1000x800")

        main_frame = tk.Frame(help_window)
        main_frame.pack(fill="both", expand=True)

        text_widget = tk.Text(main_frame, font=("Arial", 11), wrap="word", undo=True)
        text_widget.pack(side="left", fill="both", expand=True)

        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=text_widget.yview)
        scrollbar.pack(side="right", fill="y")
        text_widget.config(yscrollcommand=scrollbar.set)

        text_widget.tag_configure("h1", font=("Arial", 24, "bold"), foreground="#2c3e50", spacing1=15, spacing3=10)
        text_widget.tag_configure("h2", font=("Arial", 20, "bold"), foreground="#34495e", spacing1=12, spacing3=8)
        text_widget.tag_configure("h3", font=("Arial", 16, "bold"), foreground="#7f8c8d", spacing1=10, spacing3=6)
        text_widget.tag_configure("h4", font=("Arial", 14, "bold"), foreground="#95a5a6", spacing1=8, spacing3=4)
        text_widget.tag_configure("bold", font=("Arial", 11, "bold"))
        text_widget.tag_configure("italic", font=("Arial", 11, "italic"))
        text_widget.tag_configure("code", font=("Consolas", 10), background="#f5f5f5", foreground="#27ae60")
        text_widget.tag_configure("code_block", font=("Consolas", 9), background="#2c3e50", foreground="#ecf0f1", spacing1=5, spacing2=5, spacing3=5)
        text_widget.tag_configure("link", font=("Arial", 11, "underline"), foreground="#3498db")
        text_widget.tag_configure("hr", font=("Arial", 1), foreground="#bdc3c7")
        text_widget.tag_configure("list_item", font=("Arial", 11), lmargin1=20, lmargin2=40)
        text_widget.tag_configure("header_link", font=("Arial", 10, "bold"), foreground="#3498db")

        text_widget.tag_configure("heading_anchor", font=("Consolas", 8), foreground="#95a5a6")
        text_widget.tag_configure("table_header", font=("Arial", 11, "bold"), background="#ecf0f1")
        text_widget.tag_configure("table_cell", font=("Arial", 11))
        text_widget.tag_configure("table_sep", font=("Arial", 1))

        def render_table(lines, start_idx):
            table_lines = []
            i = start_idx
            while i < len(lines) and '|' in lines[i]:
                line = lines[i].strip()
                if re.match(r'^[\|:\-]+[\|\-:]*$', line.replace(' ', '')):
                    i += 1
                    continue
                table_lines.append(line)
                i += 1

            if len(table_lines) < 2:
                for tl in table_lines:
                    text_widget.insert(tk.END, tl + '\n', "normal")
                return i

            rows = []
            for line in table_lines:
                cells = [c.strip() for c in line.split('|')]
                if cells and cells[0] == '':
                    cells = cells[1:]
                if cells and cells[-1] == '':
                    cells = cells[:-1]
                rows.append(cells)

            col_widths = []
            for row in rows:
                while len(col_widths) < len(row):
                    col_widths.append(0)
                for j, cell in enumerate(row):
                    col_widths[j] = max(col_widths[j], len(cell))

            def render_row(row, tag):
                cells_text = []
                for j, cell in enumerate(row):
                    cells_text.append(f"│ {cell.ljust(col_widths[j])} ")
                text_widget.insert(tk.END, ''.join(cells_text) + "│\n", tag)

            render_row(rows[0], "table_header")

            sep_cells = []
            for j, width in enumerate(col_widths):
                sep_cells.append(f"├─{'─' * (width + 2)}─")
            text_widget.insert(tk.END, ''.join(sep_cells) + "┤\n", "table_sep")

            for row in rows[2:]:
                render_row(row, "table_cell")

            return i

        lines = markdown_content.split('\n')
        i = 0
        while i < len(lines):
            line = lines[i]

            if '|' in line and line.strip().startswith('|'):
                i = render_table(lines, i)
                continue

            header_match = re.match(r'^(#{1,6})\s+(.+)$', line)
            if header_match:
                level = len(header_match.group(1))
                text = header_match.group(2).strip()
                anchor_text = line.lower().replace(' ', '_').replace('#', '')

                tag = f"h{level}"
                text_widget.insert(tk.END, text, tag)
                text_widget.insert(tk.END, f"  #{anchor_text}\n", "heading_anchor")
                i += 1
                continue

            code_block_match = re.match(r'^```(\w*)$', line)
            if code_block_match:
                code_lines = []
                i += 1
                while i < len(lines) and lines[i].strip() != '```':
                    code_lines.append(lines[i])
                    i += 1
                code_text = '\n'.join(code_lines)
                text_widget.insert(tk.END, code_text + '\n', "code_block")
                text_widget.insert(tk.END, '\n', "normal")
                i += 1
                continue

            hr_match = re.match(r'^---+$', line)
            if hr_match:
                text_widget.insert(tk.END, '─' * 80 + '\n', "hr")
                i += 1
                continue

            bolditalic_match = re.match(r'^\*\*\*(.+?)\*\*\*$', line)
            if bolditalic_match:
                text_widget.insert(tk.END, bolditalic_match.group(1) + '\n', "bold")
                i += 1
                continue

            bold_match = re.match(r'^\*\*(.+?)\\*\*$', line)
            if bold_match:
                text_widget.insert(tk.END, bold_match.group(1) + '\n', "bold")
                i += 1
                continue

            italic_match = re.match(r'^\*(.+?)\*$', line)
            if italic_match and not bold_match:
                text_widget.insert(tk.END, italic_match.group(1) + '\n', "italic")
                i += 1
                continue

            inline_code_matches = list(re.finditer(r'`([^`]+)`', line))
            if inline_code_matches:
                last_end = 0
                for match in inline_code_matches:
                    text_widget.insert(tk.END, line[last_end:match.start()])
                    text_widget.insert(tk.END, match.group(1), "code")
                    last_end = match.end()
                text_widget.insert(tk.END, '\n')
                i += 1
                continue

            list_match = re.match(r'^(\s*)[-*]\s+(.+)$', line)
            if list_match:
                indent = list_match.group(1)
                text = list_match.group(2)
                bullet = "• "
                text_widget.insert(tk.END, indent + bullet + text + '\n', "list_item")
                i += 1
                continue

            numbered_match = re.match(r'^(\s*)(\d+)\.\s+(.+)$', line)
            if numbered_match:
                indent = numbered_match.group(1)
                num = numbered_match.group(2)
                text = numbered_match.group(3)
                text_widget.insert(tk.END, f"{indent}{num}. {text}\n", "list_item")
                i += 1
                continue

            if line.strip():
                text_widget.insert(tk.END, line + '\n', "normal")

            i += 1

        text_widget.config(state="disabled")

        def on_configure(event):
            text_widget.tag_add("sel", "1.0", "end")

        text_widget.bind("<Configure>", on_configure)

    def show_settings(self):
        self.clear_content()
        self.update_button_colors(3)

        title_label = tk.Label(self.content, text=self.language["settings"]["title"],
                             font=("Arial", 18, "bold"), bg="#ecf0f1")
        title_label.pack(pady=15)

        settings_container = tk.Frame(self.content, bg="#ecf0f1")
        settings_container.pack(fill="both", expand=True, padx=40, pady=10)

        lang_frame = tk.LabelFrame(settings_container, text=self.language["settings"]["language"],
                                  font=("Arial", 11, "bold"), bg="#ecf0f1", padx=10, pady=10)
        lang_frame.pack(fill="x", pady=5)

        available_langs = self.get_available_languages()
        self.lang_display_map = {}
        display_names = []
        for lang_code in available_langs:
            lang_file = os.path.join(self.language_dir, f"{lang_code}.json")
            try:
                with open(lang_file, 'r', encoding='utf-8') as f:
                    lang_data = json.load(f)
                    display_name = lang_data.get("language_name", lang_code)
                    self.lang_display_map[display_name] = lang_code
                    display_names.append(display_name)
            except:
                self.lang_display_map[lang_code] = lang_code
                display_names.append(lang_code)

        current_display_name = None
        for display_name, lang_code in self.lang_display_map.items():
            if lang_code == self.settings["language"]:
                current_display_name = display_name
                break
        if not current_display_name:
            current_display_name = self.settings["language"]

        self.lang_var = tk.StringVar(value=current_display_name)
        lang_combo = ttk.Combobox(lang_frame, textvariable=self.lang_var,
                                  values=display_names,
                                  state="readonly", font=("Arial", 11), width=20)
        lang_combo.bind("<<ComboboxSelected>>", self.on_language_changed)
        lang_combo.pack(pady=5)

        behavior_frame = tk.LabelFrame(settings_container, text=self.language["settings"]["behavior"],
                                     font=("Arial", 11, "bold"), bg="#ecf0f1", padx=10, pady=10)
        behavior_frame.pack(fill="x", pady=5)

        self.skip_failed_var = tk.BooleanVar(value=self.settings.get("skip_failed_operations", True))
        skip_check = tk.Checkbutton(behavior_frame, text=self.language["settings"]["skip_failed"],
                                   variable=self.skip_failed_var, font=("Arial", 11), bg="#ecf0f1",
                                   command=self.on_skip_failed_changed)
        skip_check.pack(anchor="w", pady=3)

        self.show_summary_var = tk.BooleanVar(value=self.settings.get("show_error_summary", True))
        summary_check = tk.Checkbutton(behavior_frame, text=self.language["settings"]["show_summary"],
                                      variable=self.show_summary_var, font=("Arial", 11), bg="#ecf0f1",
                                      command=self.on_show_summary_changed)
        summary_check.pack(anchor="w", pady=3)

        self.confirm_delete_var = tk.BooleanVar(value=self.settings.get("confirm_delete", True))
        confirm_delete_check = tk.Checkbutton(behavior_frame, text=self.language["settings"]["confirm_delete"],
                                             variable=self.confirm_delete_var, font=("Arial", 11), bg="#ecf0f1",
                                             command=self.on_confirm_delete_changed)
        confirm_delete_check.pack(anchor="w", pady=3)

        display_frame = tk.LabelFrame(settings_container, text=self.language["settings"]["display"],
                                      font=("Arial", 11, "bold"), bg="#ecf0f1", padx=10, pady=10)
        display_frame.pack(fill="x", pady=5)

        self.show_hidden_var = tk.BooleanVar(value=self.settings.get("show_hidden_files", False))
        show_hidden_check = tk.Checkbutton(display_frame, text=self.language["settings"]["show_hidden"],
                                          variable=self.show_hidden_var, font=("Arial", 11), bg="#ecf0f1",
                                          command=self.on_show_hidden_changed)
        show_hidden_check.pack(anchor="w", pady=3)

        self.sort_reverse_var = tk.BooleanVar(value=self.settings.get("sort_reverse", False))
        sort_reverse_check = tk.Checkbutton(display_frame, text=self.language["settings"]["sort_reverse"],
                                           variable=self.sort_reverse_var, font=("Arial", 11), bg="#ecf0f1",
                                           command=self.on_sort_reverse_changed)
        sort_reverse_check.pack(anchor="w", pady=3)

        file_frame = tk.LabelFrame(settings_container, text=self.language["settings"]["file_operations"],
                                  font=("Arial", 11, "bold"), bg="#ecf0f1", padx=10, pady=10)
        file_frame.pack(fill="x", pady=5)

        tk.Label(file_frame, text=self.language["settings"]["default_sort"],
                font=("Arial", 10), bg="#ecf0f1").pack(anchor="w", pady=2)

        self.default_sort_var = tk.StringVar(value=self.settings.get("default_sort", "name"))
        sort_options = [
            (self.language["file_batch"]["sort"]["name"], "name"),
            (self.language["file_batch"]["sort"]["size"], "size"),
            (self.language["file_batch"]["sort"]["time"], "time"),
            (self.language["file_batch"]["sort"]["ext"], "ext")
        ]
        for text, value in sort_options:
            tk.Radiobutton(file_frame, text=text, variable=self.default_sort_var,
                         value=value, font=("Arial", 10), bg="#ecf0f1",
                         command=self.on_default_sort_changed).pack(anchor="w", pady=1)

        version_label = tk.Label(self.content, text=f"Version 2.0.0 | Batch Command Tool",
                               font=("Arial", 9), bg="#ecf0f1", fg="#95a5a6")
        version_label.pack(side="bottom", pady=10)

    def on_skip_failed_changed(self):
        self.settings["skip_failed_operations"] = self.skip_failed_var.get()
        self.save_settings()

    def on_show_summary_changed(self):
        self.settings["show_error_summary"] = self.show_summary_var.get()
        self.save_settings()

    def on_confirm_delete_changed(self):
        self.settings["confirm_delete"] = self.confirm_delete_var.get()
        self.save_settings()

    def on_show_hidden_changed(self):
        self.settings["show_hidden_files"] = self.show_hidden_var.get()
        self.save_settings()
        if self.current_folder:
            self.load_files()

    def on_sort_reverse_changed(self):
        self.settings["sort_reverse"] = self.sort_reverse_var.get()
        self.save_settings()
        if self.current_folder:
            self.load_files()

    def on_default_sort_changed(self):
        self.settings["default_sort"] = self.default_sort_var.get()
        self.save_settings()

    def on_language_changed(self, event=None):
        display_name = self.lang_var.get()
        lang_code = self.lang_display_map.get(display_name, display_name)
        self.settings["language"] = lang_code
        self.save_settings()
        self.language = self.load_language(self.settings["language"])
        self.root.title(self.language["app_title"])
        self.title_label.config(text=self.language["app_title"])
        self.create_sidebar_buttons()

if __name__ == "__main__":
    root = tk.Tk()
    app = BatchCommandTool(root)
    root.mainloop()
